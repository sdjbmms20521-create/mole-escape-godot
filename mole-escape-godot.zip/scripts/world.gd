class_name MoleWorld
extends Node3D

## Procedural low-poly park / street / construction site.
## Ported from src/world.js. Same coordinates, zones, props and goal.

const X0 := -26.0
const X1 := 26.0
const Z0 := -50.0
const Z1 := 40.0
const W := X1 - X0
const D := Z1 - Z0
const CZ := -5.0

const BURROWABLE := ["grass", "dirt", "sand"]
const ZONE_Y := {"asphalt": 0.004, "concrete": 0.007, "dirt": 0.003, "sand": 0.022, "steel": 0.032}

var stage: Dictionary
var theme := "park"
var layout := 0
var night := false
var zones: Array = []
var blockers: Array = []
var walls: Array = []
var scrap: Array = []
var goal := Vector3.ZERO
var rng := RandomNumberGenerator.new()
var mounds: Array = []
var time := 0.0
var lamp_lights: Array[OmniLight3D] = []

var goal_glow: MeshInstance3D
var goal_glow_mat: StandardMaterial3D
var mats := {}
var glow_tex: GradientTexture2D

func setup(stage_data: Dictionary) -> void:
	stage = stage_data
	theme = str(stage.get("theme", "park"))
	layout = int(stage.get("layout", 0))
	night = bool(stage.get("night", false))
	rng.seed = 9173 + layout * 137
	goal = Vector3(float(stage.get("goal_x", 0.0)), 0.0, -46.5)
	glow_tex = _make_glow_texture()
	_build_zones()
	_build_ground()
	_build_grass()
	_build_props()
	_build_theme()
	if bool(stage.get("city", false)):
		_build_skyline()
	_build_fences()
	_build_goal()
	_build_mounds()
	_spawn_scrap(int(stage.get("scrap", 12)))

# ---------------------------------------------------------------- zones

func add_zone(type: String, x0: float, x1: float, z0: float, z1: float) -> void:
	zones.append({
		"type": type,
		"x0": maxf(X0, minf(x0, x1)),
		"x1": minf(X1, maxf(x0, x1)),
		"z0": maxf(Z0, minf(z0, z1)),
		"z1": minf(Z1, maxf(z0, z1)),
	})

func _build_zones() -> void:
	add_zone("asphalt", -26, 26, 3, 8)
	add_zone("asphalt", -26, 26, -19, -14)
	add_zone("asphalt", -12, -7, -19, 8)

	add_zone("dirt", -20, -14, 16, 22)
	add_zone("dirt", 11, 17, 14, 20)
	add_zone("dirt", 14, 20, -4, 2)

	if layout >= 1:
		add_zone("sand", 6, 24, -46, -30)
		add_zone("concrete", 6, 26, -30, -24)
		add_zone("steel", 16, 22, -40, -34)
		add_zone("dirt", -22, -16, 18, 24)
		add_zone("sand", -24, -16, -28, -20)
	if layout >= 2:
		add_zone("sand", -24, -6, -46, -34)
		add_zone("asphalt", -2, 26, -36, -32)
		add_zone("concrete", -26, 26, -30, -26)
		add_zone("dirt", -18, -12, 18, 24)
	if layout >= 1:
		add_zone("concrete", -26, 26, -44, -40)

func zone_at(x: float, z: float) -> String:
	for i in range(zones.size() - 1, -1, -1):
		var r: Dictionary = zones[i]
		if x >= r["x0"] and x <= r["x1"] and z >= r["z0"] and z <= r["z1"]:
			return str(r["type"])
	return "grass"

func can_burrow(x: float, z: float) -> bool:
	return BURROWABLE.has(zone_at(x, z))

# ---------------------------------------------------------------- ground

func _build_ground() -> void:
	var base := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(W, D)
	base.mesh = pm
	base.material_override = _surface_mat("grass", 22.0)
	base.position = Vector3(0, 0, CZ)
	add_child(base)

	for z in zones:
		var w: float = z["x1"] - z["x0"]
		var d: float = z["z1"] - z["z0"]
		var mi := MeshInstance3D.new()
		var plane := PlaneMesh.new()
		plane.size = Vector2(w, d)
		mi.mesh = plane
		if z["type"] == "steel":
			var sm := StandardMaterial3D.new()
			sm.albedo_color = Color(0.396, 0.412, 0.424)
			sm.metallic = 0.8
			sm.roughness = 0.45
			mi.material_override = sm
		else:
			var scale: float = 1.0
			match str(z["type"]):
				"dirt": scale = 2.2
				"sand": scale = 2.8
				"concrete": scale = 2.6
				_: scale = 2.4
			mi.material_override = _surface_mat(str(z["type"]), maxf(w, d) / scale)
		mi.position = Vector3((z["x0"] + z["x1"]) * 0.5, float(ZONE_Y.get(z["type"], 0.005)), (z["z0"] + z["z1"]) * 0.5)
		add_child(mi)

func _surface_mat(kind: String, repeat: float) -> StandardMaterial3D:
	var key := "surf_" + kind
	if mats.has(key):
		return mats[key]
	var base_colors := {
		"grass": Color(0.318, 0.396, 0.196),
		"asphalt": Color(0.247, 0.251, 0.243),
		"concrete": Color(0.541, 0.529, 0.482),
		"dirt": Color(0.294, 0.212, 0.133),
		"sand": Color(0.737, 0.627, 0.435),
	}
	var m := StandardMaterial3D.new()
	m.albedo_color = base_colors.get(kind, Color(0.4, 0.4, 0.4))
	var noise := FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.seed = 1337 + kind.hash()
	noise.frequency = 0.045
	noise.fractal_octaves = 4
	var tex := NoiseTexture2D.new()
	tex.width = 256
	tex.height = 256
	tex.seamless = true
	tex.noise = noise
	var ramp := Gradient.new()
	ramp.set_color(0, Color(0.68, 0.68, 0.68))
	ramp.set_color(1, Color(1.12, 1.12, 1.12))
	tex.color_ramp = ramp
	m.albedo_texture = tex
	m.uv1_scale = Vector3(repeat, repeat, 1)
	m.roughness = 0.95
	m.metallic = 0.02
	mats[key] = m
	return m

func _build_grass() -> void:
	var count := 11000
	var blade := QuadMesh.new()
	blade.size = Vector2(0.055, 0.34)
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = blade
	var placed := 0
	var guard := 0
	var colors: Array[Color] = []
	while placed < count and guard < count * 5:
		guard += 1
		var cx: float = X0 + 0.4 + rng.randf() * (W - 0.8)
		var cz: float = Z0 + 0.4 + rng.randf() * (D - 0.8)
		var t := zone_at(cx, cz)
		if t != "grass" and t != "dirt":
			continue
		var per := 4 + int(rng.randf() * 4.0)
		var spread := 0.05 + rng.randf() * 0.12
		for k in per:
			if placed >= count:
				break
			var x := cx + (rng.randf() - 0.5) * spread * 2.0
			var z := cz + (rng.randf() - 0.5) * spread * 2.0
			var basis := Basis(Vector3.UP, rng.randf() * TAU)
			basis = basis.scaled(Vector3(0.8 + rng.randf() * 0.6, (0.6 + rng.randf() * 0.95) * (0.7 + rng.randf() * 0.7), 1.0))
			mm.set_instance_transform(placed, Transform3D(basis, Vector3(x, 0, z)))
			var col := Color.from_hsv(0.21 + rng.randf() * 0.07, 0.34 + rng.randf() * 0.22, 0.14 + rng.randf() * 0.12)
			colors.append(col)
			placed += 1
	mm.instance_count = placed
	for i in placed:
		mm.set_instance_color(i, colors[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color.WHITE
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.95
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mmi.material_override = mat
	add_child(mmi)

# ---------------------------------------------------------------- helpers

func _make_mat(c: Color, rough := 0.9, metal := 0.0, emissive := Color.BLACK, energy := 0.0) -> StandardMaterial3D:
	var key := "%s_%.2f_%.2f_%s_%.2f" % [c.to_html(), rough, metal, emissive.to_html(), energy]
	if mats.has(key):
		return mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	if energy > 0.0:
		m.emission_enabled = true
		m.emission = emissive
		m.emission_energy_multiplier = energy
	mats[key] = m
	return m

func _box(pos: Vector3, size: Vector3, mat: Material, rot_y := 0.0, shadows := true) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation.y = rot_y
	if not shadows:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	return mi

func _cylinder(pos: Vector3, radius: float, height: float, mat: Material, rot := Vector3.ZERO, top := -1.0, segs := 10) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.top_radius = radius if top < 0.0 else top
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = segs
	cm.rings = 1
	var mi := MeshInstance3D.new()
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	add_child(mi)
	return mi

func _sphere(pos: Vector3, radius: float, mat: Material, scl := Vector3.ONE, segs := 10, rings := 7) -> MeshInstance3D:
	var sm := SphereMesh.new()
	sm.radius = radius
	sm.height = radius * 2.0
	sm.radial_segments = segs
	sm.rings = rings
	var mi := MeshInstance3D.new()
	mi.mesh = sm
	mi.material_override = mat
	mi.position = pos
	mi.scale = scl
	add_child(mi)
	return mi

func _random_spot(types: Array, radius_from_start := 4.0) -> Variant:
	for i in 70:
		var x: float = X0 + 1.2 + rng.randf() * (W - 2.4)
		var z: float = Z0 + 1.2 + rng.randf() * (D - 2.4)
		if Vector2(x, z - 26.0).length() < radius_from_start:
			continue
		if Vector2(x - goal.x, z - goal.z).length() < 4.5:
			continue
		if types.has(zone_at(x, z)):
			return Vector2(x, z)
	return null

func _make_glow_texture() -> GradientTexture2D:
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 1))
	g.set_color(1, Color(1, 1, 1, 0))
	g.add_point(0.45, Color(1, 1, 1, 0.35))
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	t.width = 96
	t.height = 96
	return t

func _glow_material(tint: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.albedo_texture = glow_tex
	m.albedo_color = tint
	m.no_depth_test = false
	return m

func _glow(pos: Vector3, size: float, tint: Color) -> MeshInstance3D:
	var qm := QuadMesh.new()
	qm.size = Vector2(size, size)
	var mi := MeshInstance3D.new()
	mi.mesh = qm
	mi.material_override = _glow_material(tint)
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	return mi

# ---------------------------------------------------------------- props

func _build_props() -> void:
	for i in range(15):
		var spot = _random_spot(["grass", "dirt"])
		if spot != null:
			_add_tree(spot.x, spot.y)
	for i in range(26):
		_add_bush_cluster()
	for i in range(14):
		_add_rock()

	_add_bench(-15.5, 10.6, 0.0)
	_add_bench(5.5, 0.8, PI)
	_add_bench(-1.5, -12.2, PI)
	_add_bench(19.5, -21.5, -PI * 0.5)
	_add_bench(2.0, -21.5, PI * 0.5)

	_add_lamp(-4.5, 12.5)
	_add_lamp(13.5, 12.5)
	_add_lamp(-15.5, -21.5)
	_add_lamp(10.5, -22.0)
	_add_lamp(23.5, -38.0)

	_add_bin(3.2, 9.4)
	_add_bin(-12.5, -12.2)
	_add_bin(-22.0, 4.0)

	_add_pebbles(360)
	_add_leaves(320)
	_add_mushrooms(22)
	_add_wildflowers(30)

	if layout >= 1:
		_add_sand_pile(14.5, -33.0)
		_add_sand_pile(10.0, -40.5)
		_add_sand_pile(-19.0, -23.5)
		_add_barrier(18.5, -29.2, 0.0)
		_add_barrier(13.5, -29.2, 0.0)
		_add_barrier(7.6, -36.5, PI * 0.5)
		_add_barrier(7.6, -44.2, PI * 0.5)
		_add_barrier(-12.0, -29.4, 0.0)
		_add_cone(9.5, -31.0)
		_add_cone(15.5, -28.5)
		_add_cone(21.0, -35.5)
		_add_cone(11.0, -44.6)
		_add_cone(4.5, -33.5)
		_add_concrete_blocks()
		_add_pipe(12.5, -42.5, PI * 0.5)
		_add_pipe(-14.5, -25.5, 0.4)
	if layout >= 2:
		_add_barrier(-1.0, -24.5, 0.0)
		_add_barrier(-10.0, -24.5, 0.0)
		_add_cone(-3.5, -34.0)
		_add_cone(-16.0, -38.0)
		_add_concrete_blocks(true)

func _add_tree(x: float, z: float) -> void:
	var bark := _make_mat(Color(0.341, 0.267, 0.204), 0.96)
	var foliage := [
		_make_mat(Color(0.239, 0.353, 0.169), 0.92),
		_make_mat(Color(0.290, 0.416, 0.2), 0.9),
		_make_mat(Color(0.2, 0.298, 0.145), 0.94),
	]
	var h := 2.2 + rng.randf() * 1.1
	_cylinder(Vector3(x, h * 0.5, z), 0.22, h, bark)
	var top := h
	for i in 3:
		var r := 1.35 - i * 0.28
		var mi := _sphere(Vector3(x + (rng.randf() - 0.5) * 0.35, top + i * 0.48, z + (rng.randf() - 0.5) * 0.35), r, foliage[i % 3], Vector3(1.0, 0.72, 1.0), 9, 6)
		mi.rotation.y = rng.randf() * TAU
	blockers.append({"x": x, "z": z, "r": 0.55})

func _add_bush_cluster() -> void:
	var spot = _random_spot(["grass", "dirt"], 2.0)
	if spot == null:
		return
	var greens := [Color(0.231, 0.341, 0.176), Color(0.278, 0.4, 0.204), Color(0.2, 0.31, 0.16)]
	for i in 3:
		var r := 0.35 + rng.randf() * 0.4
		var mi := _sphere(Vector3(spot.x + (rng.randf() - 0.5) * 0.9, r * 0.55, spot.y + (rng.randf() - 0.5) * 0.9), r, _make_mat(greens[i % 3], 0.95), Vector3(1.0, 0.72, 1.0), 8, 6)
		mi.rotation.y = rng.randf() * TAU

func _add_rock() -> void:
	var spot = _random_spot(["grass", "dirt", "concrete"], 3.0)
	if spot == null:
		return
	var s := 0.18 + rng.randf() * 0.35
	var mi := _sphere(Vector3(spot.x, s * 0.5, spot.y), s, _make_mat(Color(0.43, 0.42, 0.39), 0.96), Vector3(1.2, 0.7, 1.0), 7, 5)
	mi.rotation.y = rng.randf() * TAU
	if s > 0.36:
		blockers.append({"x": spot.x, "z": spot.y, "r": s * 0.8})

func _add_bench(x: float, z: float, rot_y: float) -> void:
	var g := Node3D.new()
	g.position = Vector3(x, 0, z)
	g.rotation.y = rot_y
	add_child(g)
	var wood := _make_mat(Color(0.42, 0.29, 0.19), 0.82)
	var metal := _make_mat(Color(0.33, 0.35, 0.36), 0.5, 0.7)
	for i in 3:
		_box_local(g, Vector3(0, 0.44, -0.18 + i * 0.16), Vector3(1.8, 0.055, 0.14), wood)
	for i in 2:
		var back := _box_local(g, Vector3(0, 0.68 + i * 0.16, -0.26), Vector3(1.8, 0.11, 0.05), wood)
		back.rotation.x = -0.18
	for sx in [-0.75, 0.75]:
		_box_local(g, Vector3(sx, 0.22, 0), Vector3(0.07, 0.44, 0.5), metal)
	# Same three circular blockers as the web build (surface and underground).
	for lx in [-0.55, 0.0, 0.55]:
		blockers.append({"x": x + cos(rot_y) * lx, "z": z - sin(rot_y) * lx, "r": 0.46})

func _box_local(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi

func _add_lamp(x: float, z: float) -> void:
	var metal := _make_mat(Color(0.337, 0.357, 0.369), 0.5, 0.7)
	_cylinder(Vector3(x, 1.8, z), 0.05, 3.6, metal, Vector3.ZERO, 0.045)
	_box(Vector3(x + 0.24, 3.56, z), Vector3(0.52, 0.05, 0.05), metal)
	var head_mat := _make_mat(Color(1.0, 0.89, 0.68), 0.4, 0.0, Color(1.0, 0.79, 0.47), 3.0 if night else 0.4)
	_box(Vector3(x + 0.46, 3.5, z), Vector3(0.26, 0.1, 0.18), head_mat)
	if night:
		var pool := MeshInstance3D.new()
		var q := QuadMesh.new()
		q.size = Vector2(5.2, 5.2)
		pool.mesh = q
		var pm := StandardMaterial3D.new()
		pm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		pm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		pm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		pm.albedo_texture = glow_tex
		pm.albedo_color = Color(1.0, 0.79, 0.48, 0.35)
		pool.material_override = pm
		pool.rotation.x = -PI * 0.5
		pool.position = Vector3(x + 0.46, 0.045, z)
		pool.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(pool)
		if lamp_lights.size() < 5:
			var light := OmniLight3D.new()
			light.position = Vector3(x + 0.46, 3.3, z)
			light.light_color = Color(1.0, 0.78, 0.48)
			light.light_energy = 2.2
			light.omni_range = 8.0
			light.shadow_enabled = false
			add_child(light)
			lamp_lights.append(light)
	blockers.append({"x": x, "z": z, "r": 0.16})

func _add_bin(x: float, z: float) -> void:
	var mat := _make_mat(Color(0.239, 0.29, 0.22), 0.65, 0.3)
	_cylinder(Vector3(x, 0.43, z), 0.3, 0.86, mat, Vector3.ZERO, 0.26, 12)
	blockers.append({"x": x, "z": z, "r": 0.36})

func _add_sand_pile(x: float, z: float) -> void:
	var mi := _cylinder(Vector3(x, 0.55, z), 1.7, 1.1, _surface_mat("sand", 2.0), Vector3.ZERO, 0.0, 14)
	mi.rotation.y = rng.randf() * TAU

func _add_barrier(x: float, z: float, rot_y: float) -> void:
	var metal := _make_mat(Color(0.33, 0.35, 0.36), 0.5, 0.7)
	var orange := _make_mat(Color(0.82, 0.35, 0.17), 0.62)
	var white := _make_mat(Color(0.902, 0.89, 0.847), 0.66)
	var g := Node3D.new()
	g.position = Vector3(x, 0, z)
	g.rotation.y = rot_y
	add_child(g)
	_box_local(g, Vector3(0, 0.86, 0), Vector3(1.9, 0.08, 0.08), metal)
	_box_local(g, Vector3(0, 0.44, 0), Vector3(1.9, 0.06, 0.06), metal)
	for i in 3:
		_box_local(g, Vector3(-0.62 + i * 0.62, 0.65, 0), Vector3(0.58, 0.4, 0.04), orange)
		_box_local(g, Vector3(-0.62 + i * 0.62 - 0.16, 0.65, 0.005), Vector3(0.16, 0.4, 0.045), white)
	for sx in [-0.85, 0.85]:
		_box_local(g, Vector3(sx, 0.22, 0), Vector3(0.08, 0.44, 0.3), metal)

func _add_cone(x: float, z: float) -> void:
	var orange := _make_mat(Color(0.85, 0.36, 0.15), 0.7)
	_cylinder(Vector3(x, 0.03, z), 0.26, 0.05, _make_mat(Color(0.2, 0.2, 0.2), 0.9), Vector3.ZERO, 0.26, 8)
	_cylinder(Vector3(x, 0.26, z), 0.17, 0.5, orange, Vector3.ZERO, 0.025, 8)
	_cylinder(Vector3(x, 0.32, z), 0.118, 0.08, _make_mat(Color(0.95, 0.94, 0.9), 0.7), Vector3.ZERO, 0.118, 8)

func _add_concrete_blocks(extra := false) -> void:
	var mat := _make_mat(Color(0.49, 0.48, 0.44), 0.95)
	var positions := [Vector3(2, 0.35, -30.8), Vector3(4.2, 0.35, -30.6), Vector3(-6, 0.35, -27.5), Vector3(20, 0.35, -41)]
	if extra:
		positions.append(Vector3(-20, 0.35, -27.8))
		positions.append(Vector3(-22, 0.35, -33.5))
	for p in positions:
		var b := _box(p, Vector3(1.4, 0.7, 0.9), mat, rng.randf() * 0.5)
		blockers.append({"x": b.position.x, "z": b.position.z, "r": 0.8})

func _add_pipe(x: float, z: float, rot: float) -> void:
	var metal := _make_mat(Color(0.47, 0.47, 0.43), 0.8, 0.15)
	_cylinder(Vector3(x, 0.29, z), 0.34, 2.6, metal, Vector3(PI * 0.5, rot, 0), -1, 12)

func _add_pebbles(count: int) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	var sm := SphereMesh.new()
	sm.radius = 0.06
	sm.height = 0.12
	sm.radial_segments = 6
	sm.rings = 4
	mm.mesh = sm
	var transforms: Array[Transform3D] = []
	var colors: Array[Color] = []
	for i in count:
		var x := X0 + 0.5 + rng.randf() * (W - 1.0)
		var z := Z0 + 0.5 + rng.randf() * (D - 1.0)
		if zone_at(x, z) == "grass" and rng.randf() < 0.7:
			continue
		var s := 0.4 + rng.randf() * 1.1
		transforms.append(Transform3D(Basis().scaled(Vector3(s, s * 0.5, s)), Vector3(x, 0.02, z)))
		colors.append(Color(0.38, 0.37, 0.34).lightened(rng.randf() * 0.18))
	mm.instance_count = transforms.size()
	for i in transforms.size():
		mm.set_instance_transform(i, transforms[i])
		mm.set_instance_color(i, colors[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = _make_mat(Color.WHITE, 0.95)
	var mat := mmi.material_override as StandardMaterial3D
	mat.vertex_color_use_as_albedo = true
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mmi)

func _add_leaves(count: int) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	var q := QuadMesh.new()
	q.size = Vector2(0.13, 0.07)
	mm.mesh = q
	var transforms: Array[Transform3D] = []
	var colors: Array[Color] = []
	for i in count:
		var x := X0 + 0.5 + rng.randf() * (W - 1.0)
		var z := Z0 + 0.5 + rng.randf() * (D - 1.0)
		var y: float = ZONE_Y.get(zone_at(x, z), 0.004) + 0.012
		var b := Basis(Vector3.UP, rng.randf() * TAU)
		b = b.scaled(Vector3(0.7 + rng.randf() * 0.8, 0.7 + rng.randf() * 0.8, 1.0))
		transforms.append(Transform3D(b, Vector3(x, y, z)))
		var palette := [Color(0.45, 0.3, 0.14), Color(0.38, 0.44, 0.16), Color(0.55, 0.4, 0.15)]
		colors.append(palette[i % 3].lightened(rng.randf() * 0.1))
	mm.instance_count = transforms.size()
	for i in transforms.size():
		mm.set_instance_transform(i, transforms[i])
		mm.set_instance_color(i, colors[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color.WHITE
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.95
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mmi.material_override = mat
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mmi)

func _add_mushrooms(count: int) -> void:
	for i in count:
		var spot = _random_spot(["grass", "dirt"], 2.0)
		if spot == null:
			continue
		var stem := _cylinder(Vector3(spot.x, 0.07, spot.y), 0.012, 0.14, _make_mat(Color(0.85, 0.82, 0.72), 0.85))
		stem.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_sphere(Vector3(spot.x, 0.15, spot.y), 0.055, _make_mat(Color(0.68, 0.24, 0.19), 0.75), Vector3(1.0, 0.55, 1.0), 8, 6)

func _add_wildflowers(count: int) -> void:
	for i in count:
		var spot = _random_spot(["grass", "dirt"], 2.0)
		if spot == null:
			continue
		var stem := _cylinder(Vector3(spot.x, 0.11, spot.y), 0.008, 0.22, _make_mat(Color(0.25, 0.38, 0.18), 0.9))
		stem.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var palette := [Color(0.95, 0.9, 0.75), Color(0.92, 0.75, 0.28), Color(0.78, 0.42, 0.5)]
		_sphere(Vector3(spot.x, 0.235, spot.y), 0.03, _make_mat(palette[i % 3], 0.7), Vector3.ONE, 6, 4)

# ---------------------------------------------------------------- themes

func _build_theme() -> void:
	match theme:
		"avenue":
			_add_hedge(-19.0, -6.0, 11.0, 0.0)
			_add_hedge(18.0, 9.0, 10.0, 0.02)
			_add_flower_bed(-8.0, 16.0, 5.4, 1.6)
			_add_flower_bed(4.0, -8.5, 5.0, 1.6)
			_add_topiary(-18.5, 2.5)
			_add_topiary(20.0, -4.5)
		"playground":
			_add_swing_set(17.5, -37.0, -0.15)
			_add_sand_pit(-4.0, -36.5, 6.5, 5.0)
			_add_swing_set(-16.0, 6.0, 1.57)
			_add_flower_bed(-17.0, 18.0, 4.4, 1.3)
		"construction":
			_add_scaffold(-19.0, -36.0)
			_add_pipe(-8.0, -27.0, 0.0)
			_add_cone(-21.0, -12.0)
			_add_cone(19.5, 2.5)
			_add_cone(0.0, -40.0)
		"parking":
			_add_car(-14.0, -8.0, 0.02, Color(0.3, 0.38, 0.5))
			_add_car(-7.5, -8.0, 0.0, Color(0.55, 0.2, 0.18))
			_add_car(6.0, -34.5, PI * 0.5, Color(0.58, 0.58, 0.55))
			_add_car(15.0, -33.5, PI * 0.5, Color(0.23, 0.3, 0.38))
			_add_car(-19.0, -37.0, 0.05, Color(0.35, 0.42, 0.32))
			_add_parking_lines()
			_add_lamp(2.0, -31.0)
			_add_lamp(20.0, -31.0)
		"garden":
			_add_flower_bed(-13.0, 11.0, 6.0, 1.8)
			_add_flower_bed(8.0, 9.0, 6.0, 1.8)
			_add_hedge(-19.0, -3.0, 10.0, 0.08)
			_add_hedge(14.0, -18.0, 9.0, 0.0)
			_add_topiary(-16.0, 3.0)
			_add_topiary(18.0, -12.0)
			_add_topiary(3.0, 15.0)
			_add_topiary(-6.0, -20.0)
		"drain":
			_add_pipe(-19.0, -38.0, PI * 0.5)
			_add_pipe(17.5, -27.0, 0.3)
			_add_puddle(-6.0, -14.0, 1.7)
			_add_puddle(9.0, -33.5, 1.3)
			_add_puddle(-14.0, -41.0, 1.1)
		_:
			_add_flower_bed(-17.0, 12.0, 4.6, 1.4)
			_add_flower_bed(12.5, 16.0, 4.2, 1.3)
			_add_topiary(19.0, 12.0)

func _add_hedge(x: float, z: float, length: float, rot: float) -> void:
	var mat := _make_mat(Color(0.22, 0.33, 0.18), 0.96)
	var g := Node3D.new()
	g.position = Vector3(x, 0, z)
	g.rotation.y = rot
	add_child(g)
	_box_local(g, Vector3(0, 0.7, 0), Vector3(length, 1.2, 1.1), mat)
	for i in range(int(length / 1.25)):
		var lx := -length * 0.5 + 0.7 + i * 1.25
		var top := _sphere(Vector3(lx, 1.3, 0), 0.62, mat, Vector3(1.0, 0.62, 0.95), 8, 5)
		top.reparent(g, false)
		top.position = Vector3(lx, 1.3, 0)
	for i in range(int(length / 1.4)):
		var lx := -length * 0.5 + 0.7 + i * 1.4
		blockers.append({"x": x + cos(rot) * lx, "z": z - sin(rot) * lx, "r": 0.72})

func _add_topiary(x: float, z: float) -> void:
	var bark := _make_mat(Color(0.34, 0.26, 0.19), 0.95)
	_cylinder(Vector3(x, 0.32, z), 0.09, 0.64, bark)
	_sphere(Vector3(x, 1.05, z), 0.62, _make_mat(Color(0.25, 0.37, 0.19), 0.94), Vector3(1.0, 1.2, 1.0), 9, 7)
	blockers.append({"x": x, "z": z, "r": 0.45})

func _add_flower_bed(x: float, z: float, w: float, d: float) -> void:
	var soil := _make_mat(Color(0.28, 0.2, 0.13), 0.98)
	_box(Vector3(x, 0.09, z), Vector3(w, 0.18, d), soil)
	var palette := [Color(0.9, 0.72, 0.28), Color(0.83, 0.42, 0.44), Color(0.9, 0.88, 0.78), Color(0.62, 0.48, 0.78)]
	var n := int(w * d * 1.6)
	for i in mini(n, 18):
		var px := x + (rng.randf() - 0.5) * (w - 0.4)
		var pz := z + (rng.randf() - 0.5) * (d - 0.35)
		_cylinder(Vector3(px, 0.27, pz), 0.012, 0.3, _make_mat(Color(0.24, 0.36, 0.16), 0.9))
		_sphere(Vector3(px, 0.44, pz), 0.06, _make_mat(palette[i % palette.size()], 0.72), Vector3(1.0, 0.7, 1.0), 7, 5)

func _add_swing_set(x: float, z: float, rot: float) -> void:
	var metal := _make_mat(Color(0.36, 0.37, 0.36), 0.5, 0.65)
	var seat_mat := _make_mat(Color(0.42, 0.27, 0.16), 0.85)
	var g := Node3D.new()
	g.position = Vector3(x, 0, z)
	g.rotation.y = rot
	add_child(g)
	for sx in [-2.2, 2.2]:
		var a := _box_local(g, Vector3(sx, 1.35, 0), Vector3(0.1, 2.7, 0.1), metal)
		a.rotation.z = sx * 0.045
	_box_local(g, Vector3(0, 2.65, 0), Vector3(4.7, 0.12, 0.12), metal)
	for sx in [-0.62, 0.62]:
		for sz in [-0.42, 0.42]:
			_box_local(g, Vector3(sx + sz, 1.55, 0), Vector3(0.025, 2.1, 0.025), metal)
		_box_local(g, Vector3(sx, 0.5, 0), Vector3(0.58, 0.07, 0.32), seat_mat)

func _add_sand_pit(x: float, z: float, w: float, d: float) -> void:
	var border := _make_mat(Color(0.36, 0.27, 0.18), 0.95)
	for sx in [-w * 0.5, w * 0.5]:
		_box(Vector3(x + sx, 0.12, z), Vector3(0.22, 0.24, d), border)
	for sz in [-d * 0.5, d * 0.5]:
		_box(Vector3(x, 0.12, z + sz), Vector3(w, 0.24, 0.22), border)
	var pit := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(w, d)
	pit.mesh = plane
	pit.material_override = _surface_mat("sand", 2.4)
	pit.position = Vector3(x, 0.03, z)
	add_child(pit)

func _add_scaffold(x: float, z: float) -> void:
	var metal := _make_mat(Color(0.38, 0.4, 0.41), 0.45, 0.7)
	var wood := _make_mat(Color(0.5, 0.37, 0.23), 0.9)
	for ox in [-2.2, 2.2]:
		for oz in [-1.4, 1.4]:
			_cylinder(Vector3(x + ox, 2.2, z + oz), 0.06, 4.4, metal)
	for h in [1.1, 2.3, 3.5]:
		_box(Vector3(x, h, z - 1.4), Vector3(4.5, 0.08, 0.08), metal)
		_box(Vector3(x, h, z + 1.4), Vector3(4.5, 0.08, 0.08), metal)
		_box(Vector3(x, h - 0.06, z), Vector3(4.3, 0.06, 2.8), wood)
	blockers.append({"x": x - 2.2, "z": z, "r": 1.0})
	blockers.append({"x": x + 2.2, "z": z, "r": 1.0})

func _add_car(x: float, z: float, rot: float, color: Color) -> void:
	var paint := _make_mat(color, 0.35, 0.5)
	var tire := _make_mat(Color(0.09, 0.09, 0.09), 0.9)
	var glass := _make_mat(Color(0.35, 0.48, 0.58), 0.2, 0.4)
	var g := Node3D.new()
	g.position = Vector3(x, 0, z)
	g.rotation.y = rot
	add_child(g)
	_box_local(g, Vector3(0, 0.52, 0), Vector3(1.65, 0.5, 3.3), paint)
	_box_local(g, Vector3(0, 0.98, 0.15), Vector3(1.42, 0.48, 1.7), paint)
	_box_local(g, Vector3(0, 1.02, -0.25), Vector3(1.3, 0.36, 0.05), glass)
	for sx in [-0.86, 0.86]:
		for sz in [-1.05, 1.05]:
			var wheel := _cylinder_local(g, Vector3(sx, 0.34, sz), 0.33, 0.18, tire)
			wheel.rotation.z = PI * 0.5
	blockers.append({"x": x, "z": z, "r": 1.1})
	blockers.append({"x": x + cos(rot) * 1.0, "z": z - sin(rot) * 1.0, "r": 0.9})
	blockers.append({"x": x - cos(rot) * 1.0, "z": z + sin(rot) * 1.0, "r": 0.9})

func _cylinder_local(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = 12
	var mi := MeshInstance3D.new()
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi

func _add_parking_lines() -> void:
	var white := _make_mat(Color(0.85, 0.84, 0.79), 0.8)
	for i in 13:
		_box(Vector3(X0 + 3.6 + i * 3.4, 0.011, goal.z + 13.5), Vector3(0.1, 0.006, 3.4), white, 0.0, false)

func _add_puddle(x: float, z: float, r: float) -> void:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.1, 0.12, 0.14, 0.85)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.roughness = 0.05
	mat.metallic = 0.4
	var mi := _cylinder(Vector3(x, 0.035, z), r, 0.012, mat, Vector3.ZERO, r, 20)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

func _build_skyline() -> void:
	var body := _make_mat(Color(0.25, 0.28, 0.33), 0.98)
	var far := _make_mat(Color(0.19, 0.21, 0.25), 1.0)
	var sky_rng := RandomNumberGenerator.new()
	sky_rng.seed = 7331
	for i in 26:
		var w := 4.0 + sky_rng.randf() * 7.0
		var h := 9.0 + sky_rng.randf() * 26.0
		var d := 4.0 + sky_rng.randf() * 7.0
		var b := _box(Vector3(-80.0 + (float(i) / 25.0) * 160.0 + (sky_rng.randf() - 0.5) * 5.0, h * 0.5, -60.0 - sky_rng.randf() * 26.0), Vector3(w, h, d), far if i % 3 == 0 else body, 0.0, false)
		b.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for i in 12:
		var w := 5.0 + sky_rng.randf() * 8.0
		var h := 7.0 + sky_rng.randf() * 16.0
		var b := _box(Vector3(-60.0 + (float(i) / 11.0) * 120.0 + sky_rng.randf() * 6.0, h * 0.5, 56.0 + sky_rng.randf() * 14.0), Vector3(w, h, 6.0), far, 0.0, false)
		b.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

# ---------------------------------------------------------------- fence + goal

func _build_fences() -> void:
	var fences: Array = stage.get("fences", [])
	for f in fences:
		_add_chain_fence(float(f["z"]), float(f.get("height", 1.2)))
	if theme == "drain" and fences.is_empty():
		_add_chain_fence(-21.0, 1.2)

func _add_chain_fence(z: float, height: float) -> void:
	var metal := _make_mat(Color(0.45, 0.47, 0.46), 0.42, 0.75)
	var post_x := X0 + 2.0
	while post_x < X1 - 1.0:
		_cylinder(Vector3(post_x, height * 0.5, z), 0.045, height, metal, Vector3.ZERO, 0.045, 6)
		post_x += 3.4
	for h in [height * 0.25, height * 0.68, height * 0.98]:
		_box(Vector3(0, h, z), Vector3(W - 0.5, 0.035, 0.035), metal, 0.0, false)
	# chain-link diamonds
	var line := 0.0
	while line < W - 1.0:
		var x := X0 + 0.5 + line
		for side in [-1.0, 1.0]:
			var diag := _box(Vector3(x, height * 0.6, z + side * 0.01), Vector3(0.022, height * 0.72, 0.012), metal, 0.0, false)
			diag.rotation.z = side * 0.62
		line += 0.62
	walls.append({"x0": X0, "x1": X1, "z0": z - 0.08, "z1": z + 0.08, "pad": 0.34})

func _build_goal() -> void:
	var g := Node3D.new()
	g.position = goal
	add_child(g)
	var concrete := _make_mat(Color(0.44, 0.44, 0.4), 0.92)
	var wall := _box_local(g, Vector3(0, 0.75, -1.15), Vector3(3.6, 1.5, 0.4), concrete)
	wall.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON

	var pipe_mat := _make_mat(Color(0.54, 0.53, 0.48), 0.88)
	var pipe := _cylinder_local(g, Vector3(0, 0.85, -0.25), 0.85, 2.4, pipe_mat)
	pipe.rotation.x = PI * 0.5
	pipe.name = "DrainPipe"

	var mouth := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(1.66, 1.66)
	mouth.mesh = qm
	var black := StandardMaterial3D.new()
	black.albedo_color = Color(0.02, 0.03, 0.04)
	black.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mouth.material_override = black
	mouth.position = Vector3(0, 0.85, 0.97)
	g.add_child(mouth)

	var glow := MeshInstance3D.new()
	var gq := QuadMesh.new()
	gq.size = Vector2(2.2, 2.2)
	glow.mesh = gq
	goal_glow_mat = _glow_material(Color(0.62, 0.88, 0.54, 0.55))
	glow.material_override = goal_glow_mat
	glow.position = Vector3(0, 0.85, 1.0)
	glow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	g.add_child(glow)
	goal_glow = glow

	var green := OmniLight3D.new()
	green.position = Vector3(0, 0.9, 0.9)
	green.light_color = Color(0.55, 1.0, 0.5)
	green.light_energy = 1.2
	green.omni_range = 3.2
	green.shadow_enabled = false
	g.add_child(green)

	for p in [Vector2(-2.6, 1.6), Vector2(2.7, 1.4), Vector2(-3.6, -0.4), Vector2(3.8, -0.2)]:
		var block := _box_local(g, Vector3(p.x, 0.35, p.y), Vector3(1, 0.7, 0.9), concrete)
		block.rotation.y = rng.randf() * 0.6

# ---------------------------------------------------------------- scrap + mounds

func _spawn_scrap(count: int) -> void:
	var gold := _make_mat(Color(0.85, 0.7, 0.42), 0.3, 0.85, Color(0.23, 0.16, 0.04), 0.6)
	var red := _make_mat(Color(0.71, 0.21, 0.17), 0.35, 0.6, Color(0.16, 0.03, 0.02), 0.5)
	var metal := _make_mat(Color(0.34, 0.36, 0.37), 0.5, 0.7)
	var kinds := ["coin", "cap", "screw"]
	for i in count:
		var found := false
		var x := 0.0
		var z := 0.0
		for t in 90:
			x = X0 + 1.5 + rng.randf() * (W - 3.0)
			z = Z0 + 1.5 + rng.randf() * (D - 3.0)
			if not can_burrow(x, z):
				continue
			if Vector2(x, z - 26.0).length() < 3.0:
				continue
			if Vector2(x - goal.x, z - goal.z).length() < 3.0:
				continue
			found = true
			break
		if not found:
			continue
		var kind: String = kinds[int(rng.randf() * kinds.size())]
		var node := Node3D.new()
		node.position = Vector3(x, (ZONE_Y.get(zone_at(x, z), 0.004) as float) + 0.44, z)
		add_child(node)
		if kind == "coin":
			var coin := _cylinder_local(node, Vector3.ZERO, 0.075, 0.014, gold)
			coin.rotation.x = PI * 0.5
			var torus := TorusMesh.new()
			torus.inner_radius = 0.068
			torus.outer_radius = 0.082
			torus.rings = 12
			torus.ring_segments = 6
			var rim := MeshInstance3D.new()
			rim.mesh = torus
			rim.material_override = gold
			node.add_child(rim)
		elif kind == "cap":
			var cap := _cylinder_local(node, Vector3.ZERO, 0.05, 0.018, red)
			cap.rotation.x = PI * 0.5
			var torus := TorusMesh.new()
			torus.inner_radius = 0.045
			torus.outer_radius = 0.058
			torus.rings = 12
			var rim := MeshInstance3D.new()
			rim.mesh = torus
			rim.material_override = gold
			rim.rotation.x = PI * 0.5
			node.add_child(rim)
		else:
			_cylinder_local(node, Vector3.ZERO, 0.012, 0.08, metal)
			var head := _cylinder_local(node, Vector3(0, 0.04, 0), 0.03, 0.008, metal)
			head.name = "ScrewHead"
		var glow := _glow(Vector3.ZERO, 0.46, Color(1.0, 0.88, 0.63, 0.55))
		glow.reparent(node, false)
		scrap.append({
			"node": node,
			"x": x,
			"z": z,
			"base_y": node.position.y,
			"phase": rng.randf() * TAU,
			"collected": false,
			"value": 1,
		})

func collect_scrap(entry: Dictionary) -> int:
	if bool(entry["collected"]):
		return 0
	entry["collected"] = true
	var node: Node3D = entry["node"]
	node.visible = false
	return int(entry["value"])

func _build_mounds() -> void:
	var mound_mat := _make_mat(Color(0.44, 0.33, 0.23), 1.0)
	for i in 56:
		var sm := SphereMesh.new()
		sm.radius = 1.0
		sm.height = 2.0
		sm.radial_segments = 10
		sm.rings = 6
		var mi := MeshInstance3D.new()
		mi.mesh = sm
		mi.material_override = mound_mat
		mi.visible = false
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)
		mounds.append({"node": mi, "active": false, "age": 0.0, "grow": 0.0, "size": 1.0, "x": 0.0, "z": 0.0})

func add_mound(pos: Vector3) -> void:
	var slot: Dictionary = {}
	for m in mounds:
		if not bool(m["active"]):
			slot = m
			break
	if slot.is_empty():
		slot = mounds[int(time) % mounds.size()]
	slot["active"] = true
	slot["age"] = 0.0
	slot["grow"] = 0.0
	slot["size"] = 0.72 + randf() * 0.55
	slot["x"] = pos.x
	slot["z"] = pos.z
	var node: MeshInstance3D = slot["node"]
	node.visible = true
	node.position = Vector3(pos.x, 0.004, pos.z)
	node.rotation.y = randf() * TAU
	node.scale = Vector3.ONE * 0.01

func active_mounds() -> Array:
	var out: Array = []
	for m in mounds:
		if bool(m["active"]) and float(m["age"]) < 5.6 and float(m["grow"]) > 0.25:
			out.append(m)
	return out

# ---------------------------------------------------------------- update + physics

func tick(dt: float) -> void:
	time += dt
	for s in scrap:
		if bool(s["collected"]):
			continue
		s["phase"] = float(s["phase"]) + dt
		var node: Node3D = s["node"]
		node.rotation.y += dt * 1.4
		node.position.y = float(s["base_y"]) + sin(float(s["phase"]) * 2.1) * 0.03

	for m in mounds:
		if not bool(m["active"]):
			continue
		m["age"] = float(m["age"]) + dt
		m["grow"] = minf(1.0, float(m["grow"]) + dt * 3.4)
		var age: float = m["age"]
		var fade := 1.0
		if age > 6.4:
			fade = maxf(0.0, 1.0 - (age - 6.4) / 1.4)
		var node: MeshInstance3D = m["node"]
		if fade <= 0.0:
			m["active"] = false
			node.visible = false
			continue
		var sc: float = float(m["size"]) * (0.32 + 0.68 * float(m["grow"]))
		node.scale = Vector3(0.25 * sc * fade, 0.17 * sc * fade, 0.25 * sc * fade)

	if goal_glow_mat != null:
		goal_glow_mat.albedo_color.a = 0.32 + sin(time * 2.2) * 0.12

func resolve(pos: Vector3, underground: bool) -> Vector3:
	pos.x = clampf(pos.x, X0 + 0.7, X1 - 0.7)
	pos.z = clampf(pos.z, Z0 + 1.2, Z1 - 0.7)

	if not underground:
		for w in walls:
			var pad: float = w.get("pad", 0.34)
			var x0: float = w["x0"] - pad
			var x1: float = w["x1"] + pad
			var z0: float = w["z0"] - pad
			var z1: float = w["z1"] + pad
			if pos.x > x0 and pos.x < x1 and pos.z > z0 and pos.z < z1:
				var dl := pos.x - x0
				var dr := x1 - pos.x
				var du := pos.z - z0
				var dd := z1 - pos.z
				var m := minf(minf(dl, dr), minf(du, dd))
				if m == dl:
					pos.x = x0
				elif m == dr:
					pos.x = x1
				elif m == du:
					pos.z = z0
				else:
					pos.z = z1

	for b in blockers:
		var dx := pos.x - float(b["x"])
		var dz := pos.z - float(b["z"])
		var d := sqrt(dx * dx + dz * dz)
		if d < float(b["r"]) and d > 0.0001:
			pos.x = float(b["x"]) + (dx / d) * float(b["r"])
			pos.z = float(b["z"]) + (dz / d) * float(b["r"])
	return pos

func nearest_blocker_distance(pos: Vector3) -> float:
	var best := 999.0
	for b in blockers:
		best = minf(best, Vector2(pos.x - float(b["x"]), pos.z - float(b["z"])).length() - float(b["r"]))
	return best
