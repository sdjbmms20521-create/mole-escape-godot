class_name Human
extends Node3D

## A park pedestrian. Patrols, spots the mole, investigates dirt mounds and stomps.
## Ported from src/humans.js.

signal stomped(info: Dictionary)

const TYPES := {
	"walker": {
		"shirt": Color(0.576, 0.667, 0.718), "pants": Color(0.227, 0.259, 0.314),
		"shoe": Color(0.906, 0.89, 0.855), "skin": Color(0.839, 0.643, 0.533),
		"hair": Color(0.169, 0.137, 0.114), "shoe_h": 0.09,
		"speed": 1.26, "chase": 2.65, "range": 7.0, "fov": 0.78,
		"attack_range": 1.05, "radius": 0.82, "stride": 0.95, "dmg": 30.0,
	},
	"gardener": {
		"shirt": Color(0.314, 0.42, 0.227), "pants": Color(0.231, 0.29, 0.188),
		"shoe": Color(0.278, 0.204, 0.141), "skin": Color(0.812, 0.604, 0.486),
		"hair": Color(0.2, 0.165, 0.133), "shoe_h": 0.11,
		"speed": 1.02, "chase": 2.1, "range": 8.0, "fov": 0.92,
		"attack_range": 1.2, "radius": 1.15, "stride": 1.0, "dmg": 46.0,
	},
	"worker": {
		"shirt": Color(0.882, 0.463, 0.169), "pants": Color(0.224, 0.259, 0.333),
		"shoe": Color(0.176, 0.161, 0.145), "skin": Color(0.788, 0.561, 0.435),
		"hair": Color(0.122, 0.102, 0.086), "shoe_h": 0.15,
		"speed": 0.98, "chase": 1.95, "range": 9.5, "fov": 1.02,
		"attack_range": 1.15, "radius": 0.95, "stride": 1.15, "dmg": 140.0,
	},
	"jogger": {
		"shirt": Color(0.894, 0.333, 0.227), "pants": Color(0.173, 0.204, 0.251),
		"shoe": Color(0.949, 0.937, 0.906), "skin": Color(0.878, 0.69, 0.565),
		"hair": Color(0.29, 0.2, 0.137), "shoe_h": 0.09,
		"speed": 1.85, "chase": 2.95, "range": 6.6, "fov": 0.72,
		"attack_range": 1.0, "radius": 0.8, "stride": 1.12, "dmg": 34.0,
	},
	"kid": {
		"shirt": Color(0.949, 0.757, 0.306), "pants": Color(0.239, 0.431, 0.659),
		"shoe": Color(0.914, 0.294, 0.235), "skin": Color(0.91, 0.737, 0.604),
		"hair": Color(0.165, 0.129, 0.11), "shoe_h": 0.08,
		"speed": 1.32, "chase": 2.4, "range": 6.2, "fov": 0.86,
		"attack_range": 0.95, "radius": 0.66, "stride": 0.78, "dmg": 22.0,
	},
	"guard": {
		"shirt": Color(0.184, 0.227, 0.322), "pants": Color(0.137, 0.165, 0.227),
		"shoe": Color(0.102, 0.102, 0.118), "skin": Color(0.812, 0.604, 0.486),
		"hair": Color(0.082, 0.071, 0.059), "shoe_h": 0.12,
		"speed": 1.12, "chase": 2.4, "range": 9.2, "fov": 0.98,
		"attack_range": 1.18, "radius": 0.9, "stride": 1.02, "dmg": 48.0,
	},
}

var world: MoleWorld
var type := "walker"
var speed := 1.26
var chase := 2.65
var sight := 7.0
var fov := 0.78
var attack_range := 1.05
var radius := 0.82
var stride := 0.95
var dmg := 30.0
var speed_scale := 1.0
var shoe_h := 0.09

var waypoints: Array[Vector3] = []
var wi := 0
var pos := Vector3.ZERO
var heading := 0.0
var walk_phase := 0.0
var state := "patrol"
var target := Vector3.ZERO
var attack_t := 0.0
var attack_cooldown := 0.0
var attack_pos := Vector3.ZERO
var attack_kind := "stomp"
var attack_struck := false
var investigate_kind := "mound"
var last_seen := -99.0
var step_dist := 0.0
var alive_t := 0.0

var body: Node3D
var legs: Array[Node3D] = []
var arms: Array[Node3D] = []
var head: Node3D
var shadow: MeshInstance3D
var materials: Array[StandardMaterial3D] = []

func setup(human_type: String, path: Array, scale_speed: float, world_ref: MoleWorld) -> void:
	type = human_type
	world = world_ref
	speed_scale = scale_speed
	var cfg: Dictionary = TYPES[type]
	speed = cfg["speed"]
	chase = cfg["chase"]
	sight = cfg["range"]
	fov = cfg["fov"]
	attack_range = cfg["attack_range"]
	radius = cfg["radius"]
	stride = cfg["stride"]
	dmg = cfg["dmg"]
	shoe_h = cfg["shoe_h"]

	waypoints.clear()
	for p in path:
		waypoints.append(Vector3(float(p[0]), 0.0, float(p[1])))
	if waypoints.is_empty():
		waypoints.append(Vector3.ZERO)
	pos = waypoints[0]
	wi = 0
	var nxt: Vector3 = waypoints[1] if waypoints.size() > 1 else waypoints[0]
	heading = atan2(nxt.x - pos.x, nxt.z - pos.z)
	walk_phase = randf() * TAU
	alive_t = randf() * 10.0
	scale = Vector3.ONE * randf_range(0.94, 1.06)
	_build(cfg)
	position = pos
	rotation.y = heading
	_sync_shadow()

func _build(cfg: Dictionary) -> void:
	var skin_mat := _mat(cfg["skin"], 0.72)
	var shirt_mat := _mat(cfg["shirt"], 0.86)
	var pants_mat := _mat(cfg["pants"], 0.9)
	var shoe_mat := _mat(cfg["shoe"], 0.72)
	var hair_mat := _mat(cfg["hair"], 0.95)
	var sock_mat := _mat(Color(0.902, 0.882, 0.839), 0.85)
	var dark_mat := _mat(Color(0.169, 0.149, 0.129), 0.8)

	body = Node3D.new()
	add_child(body)

	for side in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(side * 0.098, 0.88, 0)
		body.add_child(pivot)
		_capsule(pivot, Vector3(0, -0.38, 0), 0.077, 0.75, pants_mat)
		_cylinder(pivot, Vector3(0, -0.71, 0), 0.072, 0.09, sock_mat, 10)
		_box(pivot, Vector3(0, -0.76 + shoe_h * 0.5, 0.08), Vector3(0.18, shoe_h, 0.32), shoe_mat)
		_box(pivot, Vector3(0, -0.76 + shoe_h * 0.14, 0.08), Vector3(0.185, shoe_h * 0.32, 0.33), _mat(Color(0.851, 0.827, 0.784), 0.75))
		legs.append(pivot)

	_box(body, Vector3(0, 0.94, 0), Vector3(0.3, 0.2, 0.21), pants_mat)
	var torso := _capsule(body, Vector3(0, 1.16, 0), 0.17, 0.72, shirt_mat)
	torso.scale = Vector3(1.12, 1.0, 0.82)
	for sx in [-0.155, 0.155]:
		_sphere(body, Vector3(sx, 1.355, 0), 0.075, shirt_mat, Vector3(1, 0.9, 0.95))
	_cylinder(body, Vector3(0, 1.415, 0), 0.082, 0.045, shirt_mat, 12)
	_box(body, Vector3(0, 1.02, 0), Vector3(0.31, 0.045, 0.225), dark_mat)
	_cylinder(body, Vector3(0, 1.43, 0), 0.05, 0.09, skin_mat, 8)

	head = Node3D.new()
	head.position = Vector3(0, 1.55, 0)
	body.add_child(head)
	_sphere(head, Vector3.ZERO, 0.118, skin_mat, Vector3.ONE, 18, 14)
	var hair := _sphere(head, Vector3(0, 0.012, 0.008), 0.122, hair_mat, Vector3(1, 1, 1), 16, 12)
	hair.scale = Vector3(1, 0.82, 1)
	var sclera := _mat(Color(0.949, 0.925, 0.886), 0.5)
	var pupil := _mat(Color(0.165, 0.133, 0.11), 0.3)
	for sx in [-0.045, 0.045]:
		_sphere(head, Vector3(sx, 0.017, -0.101), 0.019, sclera, Vector3(1, 1.05, 0.62), 10, 8)
		_sphere(head, Vector3(sx, 0.015, -0.115), 0.0095, pupil, Vector3.ONE, 8, 6)
		var brow := _box(head, Vector3(sx, 0.056, -0.106), Vector3(0.046, 0.009, 0.013), hair_mat)
		brow.rotation.z = -0.14 if sx > 0.0 else 0.14
	for sx in [-0.118, 0.118]:
		_sphere(head, Vector3(sx, 0.002, -0.006), 0.026, skin_mat, Vector3(0.55, 1, 0.8), 8, 8)
	var nose := _cylinder(head, Vector3(0, -0.015, -0.118), 0.017, 0.04, skin_mat, 6, 0.0)
	nose.rotation.x = -PI * 0.5

	for side in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(side * 0.208, 1.348, 0)
		pivot.rotation.z = side * -0.07
		body.add_child(pivot)
		_capsule(pivot, Vector3(0, -0.12, 0), 0.055, 0.25, shirt_mat)
		_cylinder(pivot, Vector3(0, -0.238, 0), 0.053, 0.026, shirt_mat, 10)
		_capsule(pivot, Vector3(0, -0.35, 0), 0.043, 0.24, skin_mat)
		_sphere(pivot, Vector3(0, -0.468, 0), 0.05, skin_mat, Vector3(0.9, 1.2, 0.75), 10, 8)
		arms.append(pivot)

	match type:
		"walker":
			var phone := _box(arms[1], Vector3(0, -0.46, -0.06), Vector3(0.07, 0.115, 0.012), _mat(Color(0.11, 0.122, 0.133), 0.35, 0.4))
			phone.rotation.x = -0.55
			var screen := _box(phone, Vector3(0, 0.005, -0.008), Vector3(0.06, 0.1, 0.006), _mat(Color(0.749, 0.894, 1.0), 0.3, 0.0, Color(0.56, 0.78, 1.0), 1.2))
			arms[1].rotation.x = -1.05
			head.rotation.x = 0.18
		"gardener":
			var cap_mat := _mat(Color(0.224, 0.314, 0.173), 0.9)
			_cylinder(head, Vector3(0, 0.115, 0), 0.125, 0.07, cap_mat, 14, 0.13)
			var brim := _cylinder(head, Vector3(0, 0.085, -0.045), 0.16, 0.012, cap_mat, 16)
			brim.scale.z = 1.15
			var shovel := Node3D.new()
			shovel.position = Vector3(0, -0.42, -0.03)
			shovel.rotation.x = 0.15
			arms[1].add_child(shovel)
			_cylinder(shovel, Vector3(0, -0.55, 0), 0.016, 1.15, _mat(Color(0.541, 0.416, 0.247), 0.85), 8)
			_box(shovel, Vector3(0, -1.16, 0), Vector3(0.17, 0.24, 0.02), _mat(Color(0.553, 0.573, 0.584), 0.4, 0.7))
			arms[1].rotation.x = -0.25
			arms[0].rotation.x = -0.15
		"worker":
			_box(body, Vector3(0, 1.16, 0), Vector3(0.4, 0.4, 0.27), _mat(Color(0.941, 0.478, 0.133), 0.6, 0.0, Color(0.23, 0.1, 0.02), 0.5))
			for y in [1.06, 1.24]:
				_box(body, Vector3(0, y, 0), Vector3(0.41, 0.045, 0.28), _mat(Color(0.847, 0.867, 0.878), 0.5, 0.15, Color(0.23, 0.25, 0.26), 0.35))
			var helmet := _sphere(head, Vector3(0, 0.05, 0), 0.135, _mat(Color(0.941, 0.757, 0.188), 0.45), Vector3(1, 0.7, 1), 18, 12)
			helmet.scale.y = 0.62
			_cylinder(head, Vector3(0, 0.035, 0), 0.16, 0.018, _mat(Color(0.941, 0.757, 0.188), 0.45), 16)
			arms[0].rotation.x = 0.05
			arms[1].rotation.x = 0.05
		"jogger":
			var band := TorusMesh.new()
			band.inner_radius = 0.098
			band.outer_radius = 0.128
			band.rings = 16
			band.ring_segments = 6
			var band_mi := MeshInstance3D.new()
			band_mi.mesh = band
			band_mi.material_override = _mat(Color(0.114, 0.153, 0.2), 0.75)
			band_mi.rotation.x = PI * 0.5
			band_mi.position = Vector3(0, 0.06, 0)
			head.add_child(band_mi)
			var stripe_mat := _mat(Color(0.957, 0.945, 0.91), 0.8)
			for side in [-1.0, 1.0]:
				_box(body, Vector3(side * 0.16, 1.15, -0.14), Vector3(0.02, 0.5, 0.02), stripe_mat)
		"kid":
			body.scale = Vector3.ONE * 0.76
			_box(body, Vector3(0, 1.15, 0.16), Vector3(0.26, 0.3, 0.17), _mat(Color(0.851, 0.333, 0.184), 0.85))
			for sx in [-0.1, 0.1]:
				_box(body, Vector3(sx, 1.2, -0.152), Vector3(0.035, 0.34, 0.02), _mat(Color(0.227, 0.227, 0.227), 0.9))
			var cap_mat := _mat(Color(0.31, 0.545, 0.839), 0.8)
			var cap_top := _sphere(head, Vector3(0, 0.05, 0), 0.126, cap_mat, Vector3(1, 0.7, 1), 16, 10)
			cap_top.scale.y = 0.62
			var brim := _cylinder(head, Vector3(0, 0.028, -0.055), 0.15, 0.014, cap_mat, 16)
			brim.scale.z = 1.15
		"guard":
			var cap_mat := _mat(Color(0.114, 0.141, 0.204), 0.85)
			var cap_top := _sphere(head, Vector3(0, 0.05, 0), 0.128, cap_mat, Vector3(1, 0.68, 1), 16, 10)
			cap_top.scale.y = 0.62
			var brim := _cylinder(head, Vector3(0, 0.026, -0.05), 0.152, 0.015, cap_mat, 16)
			brim.scale.z = 1.18
			_box(body, Vector3(-0.11, 1.24, -0.14), Vector3(0.05, 0.05, 0.014), _mat(Color(0.839, 0.706, 0.388), 0.4, 0.6))
			var torch := _cylinder(arms[1], Vector3(0, -0.5, -0.06), 0.032, 0.16, _mat(Color(0.169, 0.184, 0.2), 0.5, 0.4), 8)
			torch.rotation.x = PI * 0.5
			arms[1].rotation.x = -0.18

	shadow = MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.5
	sm.height = 1.0
	sm.radial_segments = 14
	sm.rings = 6
	shadow.mesh = sm
	var sh_mat := StandardMaterial3D.new()
	sh_mat.albedo_color = Color(0.02, 0.015, 0.01, 0.42)
	sh_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sh_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	shadow.material_override = sh_mat
	shadow.scale = Vector3(0.85, 0.02, 1.1)
	shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	shadow.top_level = true
	add_child(shadow)
	_sync_shadow()

func update(dt: float, player: MolePlayer) -> void:
	alive_t += dt
	attack_cooldown = maxf(0.0, attack_cooldown - dt)

	if state == "attack":
		_update_attack(dt)
		_sync()
		return

	var dx := player.position.x - pos.x
	var dz := player.position.z - pos.z
	var dist_player := sqrt(dx * dx + dz * dz)
	var buried := player.underground()
	var in_grass := world.zone_at(player.position.x, player.position.z) == "grass"
	var range := sight * (1.35 if player.noise > 0.6 else 0.8 if in_grass else 1.0)
	var angle_to := absf(wrapf(atan2(dx, dz) - heading, -PI, PI))
	var sees := not buried and not player.dead and dist_player < range and (angle_to < fov or dist_player < 1.9)
	var mound: Variant = _nearest_mound()

	if sees:
		state = "chase"
		target = player.position
		last_seen = alive_t
	elif state == "chase" and alive_t - last_seen > 4.5 and not sees:
		state = "patrol"
	elif state != "chase" and mound != null and dist_player > 2.6:
		state = "investigate"
		investigate_kind = "mound"
		target = Vector3(float(mound["x"]), 0, float(mound["z"]))

	if state == "chase":
		if dist_player < attack_range and not buried and attack_cooldown <= 0.0:
			_start_attack(player.position, "stomp")
			return
		_move_towards(target, chase * speed_scale, dt)
	elif state == "investigate":
		var d := Vector2(target.x - pos.x, target.z - pos.z).length()
		if d < 0.7:
			if investigate_kind == "mound" and attack_cooldown <= 0.0:
				_start_attack(target, "stomp")
				return
			state = "patrol"
		else:
			_move_towards(target, speed * 1.45 * speed_scale, dt)
	else:
		var wp: Vector3 = waypoints[wi]
		var d := Vector2(wp.x - pos.x, wp.z - pos.z).length()
		if d < 0.7:
			wi = (wi + 1) % waypoints.size()
		else:
			_move_towards(wp, speed * speed_scale, dt)

	_animate(dt)
	_sync()

func _start_attack(at: Vector3, kind: String) -> void:
	state = "attack"
	attack_t = 0.0
	attack_pos = at
	attack_struck = false
	attack_kind = "shovel" if type == "gardener" else kind
	heading = atan2(at.x - pos.x, at.z - pos.z)
	rotation.y = heading

func _update_attack(dt: float) -> void:
	attack_t += dt
	var a := attack_t
	if attack_kind == "shovel":
		var raise := minf(1.0, a / 0.3)
		var strike := 0.0 if a < 0.3 else minf(1.0, (a - 0.3) / 0.12)
		arms[0].rotation.x = -0.2 - raise * 1.5 + strike * 2.1
		arms[1].rotation.x = -0.2 - raise * 1.5 + strike * 2.1
		body.rotation.x = strike * 0.3
	else:
		if a < 0.32:
			legs[1].rotation.x = -1.15 * (a / 0.32)
		elif a < 0.44:
			legs[1].rotation.x = -1.15 + ((a - 0.32) / 0.12) * 1.75
		else:
			legs[1].rotation.x = 0.6 * maxf(0.0, 1.0 - (a - 0.44) / 0.35)
		body.rotation.x = 0.16 if a > 0.32 else -0.05

	if not attack_struck and a > 0.36:
		attack_struck = true
		stomped.emit({
			"pos": attack_pos,
			"type": type,
			"dmg": dmg,
			"kind": attack_kind,
			"radius": radius,
		})

	if a > 0.98:
		state = "patrol"
		attack_cooldown = 1.15
		body.rotation.x = 0.0
		legs[1].rotation.x = 0.0
		arms[0].rotation.x = -0.05 if type == "walker" else -0.15
		arms[1].rotation.x = -1.05 if type == "walker" else -0.25

func _nearest_mound() -> Variant:
	var best: Variant = null
	var best_d := sight * 0.8
	for m in world.active_mounds():
		var d := Vector2(float(m["x"]) - pos.x, float(m["z"]) - pos.z).length()
		if d < best_d:
			best = m
			best_d = d
	return best

func _move_towards(at: Vector3, move_speed: float, dt: float) -> void:
	var dx := at.x - pos.x
	var dz := at.z - pos.z
	var d := sqrt(dx * dx + dz * dz)
	if d < 0.0001:
		return
	var nx := dx / d
	var nz := dz / d
	var step := minf(d, move_speed * dt)
	pos.x += nx * step
	pos.z += nz * step

	for b in world.blockers:
		var bx := pos.x - float(b["x"])
		var bz := pos.z - float(b["z"])
		var bd := sqrt(bx * bx + bz * bz)
		var rr := float(b["r"]) + 0.22
		if bd < rr and bd > 0.0001:
			pos.x = float(b["x"]) + (bx / bd) * rr
			pos.z = float(b["z"]) + (bz / bd) * rr

	var desired := atan2(nx, nz)
	var diff := wrapf(desired - heading, -PI, PI)
	heading += diff * minf(1.0, dt * 6.0)
	step_dist += step
	var stride_now := stride * 0.78 if state == "chase" else stride
	if step_dist > stride_now:
		step_dist = 0.0

func _animate(dt: float) -> void:
	var move_speed := (chase if state == "chase" else speed) * speed_scale
	var amp := 0.4 + minf(0.5, move_speed * 0.16)
	walk_phase += dt * (2.8 + move_speed * 2.3)
	var s := sin(walk_phase)
	legs[0].rotation.x = s * amp
	legs[1].rotation.x = -s * amp
	body.position.y = absf(s) * 0.035

	if type == "walker":
		arms[0].rotation.x = -s * amp * 0.85
		arms[1].rotation.x = -1.05 + sin(walk_phase * 0.5) * 0.04
	elif type == "gardener":
		arms[0].rotation.x = -s * amp * 0.7 - 0.15
		arms[1].rotation.x = s * amp * 0.25 - 0.25
	else:
		arms[0].rotation.x = -s * amp * 0.9 + 0.05
		arms[1].rotation.x = s * amp * 0.9 + 0.05

	body.rotation.z = s * 0.02
	head.rotation.y = sin(walk_phase * 0.4) * 0.12

func _sync() -> void:
	position = pos
	rotation.y = heading
	rotation.x = 0.0
	_sync_shadow()

func _sync_shadow() -> void:
	if shadow != null:
		shadow.position = Vector3(pos.x, 0.014, pos.z)
		shadow.visible = true

# ---------------------------------------------------------------- primitives

func _mat(c: Color, rough: float, metal := 0.0, emissive := Color.BLACK, energy := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	if energy > 0.0:
		m.emission_enabled = true
		m.emission = emissive
		m.emission_energy_multiplier = energy
	materials.append(m)
	return m

func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi

func _cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material, segs := 8, top := -1.0) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.top_radius = radius if top < 0.0 else top
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = segs
	cm.rings = 1
	var mi := MeshInstance3D.new()
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi

func _sphere(parent: Node3D, pos: Vector3, radius: float, mat: Material, scl := Vector3.ONE, segs := 10, rings := 8) -> MeshInstance3D:
	var sm := SphereMesh.new()
	sm.radius = radius
	sm.height = radius * 2.0
	sm.radial_segments = segs
	sm.rings = rings
	var mi := MeshInstance3D.new()
	mi.mesh = sm
	mi.material_override = mat
	mi.position = pos
	mi.scale = scl
	parent.add_child(mi)
	return mi

func _capsule(parent: Node3D, pos: Vector3, r: float, h: float, mat: Material) -> MeshInstance3D:
	var cm := CapsuleMesh.new()
	cm.radius = r
	cm.height = maxf(h, r * 2.01)
	cm.radial_segments = 8
	cm.rings = 4
	var mi := MeshInstance3D.new()
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi
