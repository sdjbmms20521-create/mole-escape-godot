extends SceneTree

## Headless smoke test:
##   godot --headless --path godot --script res://tests/smoke.gd
## Checks stage construction, burrow state machine, damage/helmet, fences,
## the 20-person final stage, and the shop purchase path.

var failures := 0

func _initialize() -> void:
	_run.call_deferred()

func _check(ok: bool, label: String) -> void:
	if ok:
		print("PASS  ", label)
	else:
		failures += 1
		printerr("FAIL  ", label)

func _run() -> void:
	var main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	await process_frame

	_check(main.mode == main.Mode.MENU, "boots into menu")
	_check(main.title.visible, "title screen visible")
	_check(not main.hud.hud_root.visible, "gameplay HUD hidden in menu")
	_check(main.hud.hearts.size() == 3, "health renders as three hearts")

	main.start_run()
	await process_frame

	_check(main.mode == main.Mode.PLAYING, "start_run enters playing mode")
	_check(main.world != null and main.player != null and main.humans != null, "stage 1 built")
	_check(main.humans.list.size() == 4, "stage 1 has 4 humans")
	_check(main.world.can_burrow(0.0, 26.0), "grass at spawn is burrowable")
	_check(not main.world.can_burrow(-9.5, 0.0), "asphalt road is not burrowable")
	_check(main.world.zones.size() > 5, "zone layout generated")

	var player = main.player
	player.set_air(7.6)
	_check(is_equal_approx(player.air_max, 5.0), "air time capped at 5s")

	player.position = Vector3(0, 0, 26)
	player.state = MolePlayer.SURFACE
	player.update(0.016, Vector2.ZERO, Vector2.ZERO, true, false)
	_check(player.state == MolePlayer.DIVING, "holding dig starts burrow")
	for i in 30:
		player.update(0.02, Vector2.ZERO, Vector2.ZERO, true, false)
	_check(player.state == MolePlayer.UNDER, "burrow transitions underground")
	_check(player.oxygen < 1.0, "oxygen drains underground")
	player.update(0.016, Vector2.ZERO, Vector2.ZERO, false, false)
	for i in 30:
		player.update(0.02, Vector2.ZERO, Vector2.ZERO, false, false)
	_check(player.state == MolePlayer.SURFACE, "releasing dig surfaces")

	player.health = 100.0
	player.invuln = 0.0
	var result: String = player.handle_stomp({"pos": player.position, "radius": 0.82, "dmg": 30.0, "kind": "stomp"})
	_check(result == "hit" and is_equal_approx(player.health, 70.0), "stomp deals 30 damage")
	player.invuln = 0.0
	player.set_helmet(true)
	result = player.handle_stomp({"pos": player.position, "radius": 0.82, "dmg": 30.0, "kind": "stomp"})
	_check(result == "helmet" and is_equal_approx(player.health, 70.0), "helmet absorbs one stomp")

	main.build_stage(6, true)
	await process_frame
	_check(main.humans.list.size() == 20, "final stage has 20 humans")
	_check(main.world.walls.size() >= 1, "final stage has a fence wall")
	var surface: Vector3 = main.world.resolve(Vector3(0, 0, -21.0), false)
	var below: Vector3 = main.world.resolve(Vector3(0, 0, -21.0), true)
	_check(absf(surface.z + 21.0) > 0.3, "fence blocks on the surface")
	_check(absf(below.z + 21.0) < 0.01, "fence can be passed underground")
	_check(is_equal_approx(main.player.air_max, 4.6), "final stage air is 4.6s")
	_check(main.player.dig_cooldown_max == 5.0, "final stage dig cooldown is 5s")

	main.scrap = 10
	main._open_shop(0, false)
	_check(main.mode == main.Mode.SHOP, "shop opens")
	_check(main.hud.overlay_root.visible, "shop overlay visible")
	main._on_buy("drink")
	_check(int(main.charges["drink"]) == 1, "buying a drink adds a charge")
	_check(main.scrap == 7, "buying a drink costs 3 scrap")
	main._on_depart()
	await process_frame
	_check(main.mode == main.Mode.PLAYING, "departing the shop starts the stage")
	_check(main.player.state == MolePlayer.SURFACE, "new stage starts on the surface")

	# Clear the stage: standing on the drain should hand over to the shop.
	main.stage_time = 9.0
	main.player.position = main.world.goal + Vector3(0, 0, 1.1)
	main.player.state = MolePlayer.SURFACE
	main._tick_playing(0.016)
	_check(main.mode == main.Mode.ESCAPED, "reaching the drain clears the stage")
	await create_timer(1.1).timeout
	_check(main.mode == main.Mode.SHOP and main.shop_index == 1, "stage clear opens the next shop")
	_check(main.records["stages"].has("0"), "stage best time is saved")

	main._on_depart()
	await process_frame
	# Death and retry should keep the running stage clock.
	main.stage_time = 4.0
	main.player.invuln = 0.0
	main._on_stomp({"pos": main.player.position, "radius": 1.0, "dmg": 140.0, "kind": "stomp"})
	_check(main.mode == main.Mode.DEAD, "a heavy stomp ends the run")
	await create_timer(1.0).timeout
	_check(main.hud.overlay_root.visible, "death screen appears")
	main._on_retry()
	_check(main.mode == main.Mode.SHOP and main.retrying, "retry opens the same stage shop")
	main._on_depart()
	await process_frame
	_check(absf(main.stage_time - 4.0) < 0.5, "retrying the same stage keeps the timer")

	print("SMOKE_RESULT ", "OK" if failures == 0 else "FAILED (%d)" % failures)
	quit(0 if failures == 0 else 1)
