class_name Humans
extends Node3D

signal stomped(info: Dictionary)

var list: Array[Human] = []

func setup(world: MoleWorld, stage: Dictionary) -> void:
	var mix := {
		"walker": ["walker", "walker", "jogger", "kid", "walker", "jogger"],
		"gardener": ["gardener", "gardener", "guard"],
		"worker": ["worker", "worker", "guard"],
	}
	var defs: Array = stage.get("humans", [])
	var speed_scale := float(stage.get("humans_speed", 1.0))
	for i in defs.size():
		var def: Dictionary = defs[i]
		var base_type := str(def.get("type", "walker"))
		var pool: Array = mix.get(base_type, [base_type])
		var human_type := str(pool[i % pool.size()])
		var h := Human.new()
		h.name = "Human_%d" % i
		add_child(h)
		h.setup(human_type, def.get("path", []), speed_scale, world)
		h.stomped.connect(_on_human_stomped)
		list.append(h)

func _on_human_stomped(info: Dictionary) -> void:
	stomped.emit(info)

func update(dt: float, player: MolePlayer) -> void:
	for h in list:
		h.update(dt, player)

func nearest_distance(pos: Vector3) -> float:
	var best := 999.0
	for h in list:
		best = minf(best, Vector2(h.pos.x - pos.x, h.pos.z - pos.z).length())
	return best

func human_count() -> int:
	return list.size()
