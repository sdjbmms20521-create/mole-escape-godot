class_name MolePlayer
extends Node3D

## Third-person mole controller: burrow state machine, oxygen, health, camera.
## Values and feel ported from src/player.js.

const SURFACE := "surface"
const DIVING := "diving"
const UNDER := "under"
const RISING := "rising"

var world: MoleWorld
var camera: Camera3D
var sfx: Sfx
var mole: MoleModel

var yaw := 0.0
var pitch := 0.4
var facing := 0.0

var state := SURFACE
var state_timer := 0.0
var oxygen := 1.0
var air_max := 5.0
var health := 100.0
var invuln := 0.0
var stun := 0.0
var buff := 0.0
var dig_cooldown := 0.0
var dig_cooldown_max := 0.0
var helmet := false
var dead := false

var shake := 0.0
var hurt := 0.0
var noise := 0.0
var anim_phase := 0.0
var idle_t := 0.0
var idle_look := 0.0
var dig_phase := 0.0
var mound_dist := 0.0
var step_dist := 0.0
var dig_sound_timer := 0.0
var bump_timer := 0.0
var moving := 0.0
var foot_zone := "grass"

var cam_ready := false
var cam_target := Vector3.ZERO
var cam_desired := Vector3.ZERO

func setup(world_ref: MoleWorld, cam: Camera3D, audio: Sfx) -> void:
	world = world_ref
	camera = cam
	sfx = audio
	position = Vector3(0, 0, 26)
	yaw = 0.0
	pitch = 0.4
	mole = MoleModel.new()
	mole.name = "MoleModel"
	add_child(mole)
	_place_camera(true)

func underground() -> bool:
	return state == UNDER or state == DIVING

func add_shake(v: float) -> void:
	shake = maxf(shake, v)

func apply_buff(seconds: float) -> void:
	buff = maxf(buff, seconds)

func set_helmet(on: bool) -> void:
	helmet = on

func set_air(seconds: float) -> void:
	# A single dig never keeps the mole underground longer than 5 seconds.
	air_max = maxf(3.4, minf(5.0, seconds if seconds > 0.0 else 5.0))

func set_dig_cooldown(seconds: float) -> void:
	dig_cooldown_max = maxf(0.0, seconds)
	dig_cooldown = 0.0

func force_surface() -> void:
	if state == UNDER or state == DIVING:
		state = RISING
		state_timer = 0.0
		oxygen = maxf(oxygen, 0.4)
		if sfx != null:
			sfx.play("dig", -12.0, 1.25)

func handle_stomp(info: Dictionary) -> String:
	if dead:
		return "miss"
	var target: Vector3 = info.get("pos", Vector3.ZERO)
	var d := Vector2(position.x - target.x, position.z - target.z).length()
	if d > float(info.get("radius", 0.8)):
		return "miss"
	if invuln > 0.0:
		return "miss"

	if helmet:
		helmet = false
		invuln = 1.8
		stun = minf(stun, 0.2)
		force_surface()
		add_shake(1.25)
		if sfx != null:
			sfx.play("crack")
		return "helmet"

	var dmg := float(info.get("dmg", 30))
	if str(info.get("kind", "")) == "shovel":
		dmg = maxf(dmg, 44.0)

	health -= dmg
	invuln = 0.9
	hurt = 1.0
	add_shake(1.7 if dmg >= 100.0 else 1.0)
	if sfx != null:
		sfx.play("hurt")
	if health <= 0.0:
		health = 0.0
		dead = true
		if sfx != null:
			sfx.play("hurt", -2.0, 0.8)
		return "dead"
	return "hit"

func update(dt: float, axes: Vector2, look: Vector2, dig_held: bool, sprint: bool) -> void:
	invuln = maxf(0.0, invuln - dt)
	stun = maxf(0.0, stun - dt)
	buff = maxf(0.0, buff - dt)
	dig_cooldown = maxf(0.0, dig_cooldown - dt)
	shake *= exp(-5.0 * dt)
	hurt = maxf(0.0, hurt - dt * 2.2)
	idle_t += dt

	if not dead:
		yaw -= look.x
		pitch = clampf(pitch + look.y * 0.9, 0.07, 1.05)

	if axes.length() > 1.0:
		axes = axes.normalized()
	var mag: float = clampf(axes.length(), 0.0, 1.0) if not dead else 0.0
	moving = lerpf(moving, mag, minf(1.0, dt * 8.0))
	foot_zone = world.zone_at(position.x, position.z)
	var hard := not world.can_burrow(position.x, position.z)

	# ---------------- burrow state machine ----------------
	if not dead and stun <= 0.0:
		if state == SURFACE:
			if dig_held and dig_cooldown <= 0.0 and world.can_burrow(position.x, position.z):
				state = DIVING
				state_timer = 0.0
				if sfx != null:
					sfx.play("dig")
		elif state == DIVING:
			state_timer += dt
			if state_timer > 0.34:
				state = UNDER
				state_timer = 0.0
				mound_dist = 0.0
				world.add_mound(position)
		elif state == UNDER:
			if not dig_held:
				state = RISING
				state_timer = 0.0
				if sfx != null:
					sfx.play("dig", -12.0, 1.3)
		elif state == RISING:
			state_timer += dt
			if state_timer > 0.28:
				state = SURFACE
				state_timer = 0.0
				if dig_cooldown_max > 0.0:
					dig_cooldown = dig_cooldown_max

	# ---------------- oxygen ----------------
	if state == UNDER:
		oxygen -= dt / air_max
		if oxygen <= 0.0:
			oxygen = 0.0
			state = RISING
			state_timer = 0.0
			stun = 1.15
			add_shake(0.5)
			if sfx != null:
				sfx.play("hurt", -10.0, 1.4)
	elif state == SURFACE:
		oxygen = minf(1.0, oxygen + dt * 0.55)
	else:
		oxygen = minf(1.0, oxygen + dt * 0.15)

	# ---------------- movement ----------------
	var fx := -sin(yaw)
	var fz := -cos(yaw)
	var rx := cos(yaw)
	var rz := -sin(yaw)
	var vx: float = fx * axes.y + rx * axes.x
	var vz: float = fz * axes.y + rz * axes.x
	var vlen := sqrt(vx * vx + vz * vz)
	if vlen > 1.0:
		vx /= vlen
		vz /= vlen

	var speed := 0.0
	if state == UNDER:
		speed = 1.32 * (1.6 if buff > 0.0 else 1.0)
	elif state == DIVING or state == RISING:
		speed = 0.72
	else:
		speed = (3.45 if sprint else 1.95) * (1.42 if buff > 0.0 else 1.0) * (0.95 if hard else 1.0)
	if stun > 0.0 or dead:
		speed *= 0.25

	var step := speed * dt * mag
	var prev := position
	var next := position
	next.x += vx * step
	next.z += vz * step

	if step > 0.0001:
		if underground():
			if world.can_burrow(next.x, next.z):
				position = next
			else:
				bump_timer += dt
				if bump_timer > 0.35:
					bump_timer = 0.0
					add_shake(0.22)
		else:
			position = next
		position = world.resolve(position, underground())
		# Solid props can push the mole onto hard ground; never let that trap it underground.
		if underground() and not world.can_burrow(position.x, position.z):
			position = prev

	var moved := Vector2(position.x - prev.x, position.z - prev.z).length()
	if moved > 0.0005 and vlen > 0.05:
		var desired := atan2(-vx, -vz)
		facing += wrapf(desired - facing, -PI, PI) * minf(1.0, dt * 11.0)
		idle_look = 0.0
	elif not underground() and not dead:
		idle_look += dt
		if idle_look > 1.4:
			var toward_cam := yaw + PI
			facing += wrapf(toward_cam - facing, -PI, PI) * minf(1.0, dt * 3.2)

	# ---------------- noise / footsteps ----------------
	var on_hard := not world.can_burrow(position.x, position.z)
	noise = 0.0
	if not dead and state != UNDER and state != DIVING and mag > 0.08:
		if on_hard:
			noise = 1.4 if sprint else 0.95
		else:
			noise = 0.6 if sprint else 0.22
	if state == SURFACE and not dead:
		step_dist += moved
		var stride := 0.85 if sprint else 0.62
		if step_dist > stride:
			step_dist = 0.0
			if sfx != null:
				sfx.play("click", -30.0, 0.7 if foot_zone == "grass" else 1.1)

	# ---------------- mound trail / digging ----------------
	if state == UNDER:
		mound_dist += moved
		if mound_dist > 0.34:
			mound_dist = 0.0
			world.add_mound(position)
		dig_sound_timer -= dt
		if dig_sound_timer <= 0.0:
			dig_sound_timer = 0.16
			if sfx != null:
				sfx.play("dig", -22.0, randf_range(0.9, 1.1))
			dig_phase += dt * 11.0
	elif state == DIVING:
		dig_sound_timer -= dt
		if dig_sound_timer <= 0.0:
			dig_sound_timer = 0.07
			dig_phase += 1.0

	mole.rotation.y = facing
	mole.animate(dt, state, state_timer, mag, sprint, dig_phase, dead, hurt, buff > 0.0)
	_update_camera(dt)

func _update_camera(dt: float) -> void:
	var under := underground()
	var dist := 0.86 if under else 0.84
	var p: float = clampf(pitch, 0.5, 0.92) if under else pitch
	var behind := Vector3(sin(yaw) * cos(p) * dist, maxf(0.05, (0.34 if under else 0.1) + sin(p) * dist), cos(yaw) * cos(p) * dist)
	var jitter := shake * 0.035
	cam_desired = position + behind + Vector3(randf_range(-0.5, 0.5) * jitter, randf_range(-0.5, 0.5) * jitter, randf_range(-0.5, 0.5) * jitter)

	if not cam_ready:
		camera.position = cam_desired
		cam_ready = true
	else:
		camera.position = camera.position.lerp(cam_desired, 1.0 - exp(-13.0 * dt))

	var look_y := 0.03 if under else 0.125
	cam_target = Vector3(position.x, look_y, position.z)
	if camera.position.distance_to(cam_target) > 0.001:
		camera.look_at(cam_target, Vector3.UP)

func _place_camera(instant := false) -> void:
	var behind := Vector3(sin(yaw) * cos(pitch) * 0.84, maxf(0.05, 0.1 + sin(pitch) * 0.84), cos(yaw) * cos(pitch) * 0.84)
	cam_desired = position + behind
	if instant:
		camera.position = cam_desired
		cam_ready = true
	camera.look_at(Vector3(position.x, 0.125, position.z), Vector3.UP)

func goal_distance() -> float:
	return Vector2(position.x - world.goal.x, position.z - world.goal.z).length()
