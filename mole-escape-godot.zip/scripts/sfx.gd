class_name Sfx
extends Node

## Tiny procedural sound kit — no audio files needed.

const RATE := 22050
const VOICES := 8

var streams := {}
var players: Array[AudioStreamPlayer] = []
var cursor := 0
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	rng.seed = 4242
	for i in VOICES:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		players.append(p)
	_build()

func _build() -> void:
	streams["click"] = _tone(0.055, 820.0, 1180.0, 0.16, 0.003, 0.03)
	streams["dig"] = _noise(0.09, 0.22, 380.0)
	streams["pickup"] = _arp([880.0, 1318.0], 0.07, 0.2)
	streams["hurt"] = _tone(0.3, 220.0, 70.0, 0.3, 0.004, 0.18, true)
	streams["crack"] = _noise(0.16, 0.26, 1400.0)
	streams["stomp"] = _thump(0.22, 82.0, 0.34)
	streams["win"] = _arp([523.25, 659.25, 783.99, 1046.5], 0.12, 0.2)
	streams["alert"] = _tone(0.18, 420.0, 620.0, 0.12, 0.005, 0.12)
	streams["heart"] = _thump(0.12, 58.0, 0.24)
	streams["ui"] = _tone(0.07, 560.0, 720.0, 0.12, 0.004, 0.04)

func play(name: String, volume_db := -7.0, pitch := 1.0) -> void:
	if not streams.has(name):
		return
	var p := players[cursor % players.size()]
	cursor += 1
	p.stream = streams[name]
	p.volume_db = volume_db
	p.pitch_scale = pitch
	p.play()

func _new_stream(duration: float, samples: PackedFloat32Array) -> AudioStreamWAV:
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	var data := PackedByteArray()
	data.resize(samples.size() * 2)
	for i in samples.size():
		data.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32767.0))
	wav.data = data
	return wav

func _tone(duration: float, f0: float, f1: float, amp: float, attack: float, release: float, saw := false) -> AudioStreamWAV:
	var count := int(duration * RATE)
	var out := PackedFloat32Array()
	out.resize(count)
	var phase := 0.0
	for i in count:
		var t := float(i) / RATE
		var k := clampf(t / duration, 0.0, 1.0)
		var f: float = lerpf(f0, f1, k)
		phase += TAU * f / RATE
		var s: float = sin(phase)
		if saw:
			s = 0.6 * s + 0.4 * (2.0 * fmod(phase / TAU, 1.0) - 1.0)
		var env := minf(1.0, t / maxf(0.0001, attack)) * minf(1.0, (duration - t) / maxf(0.0001, release))
		out[i] = s * amp * maxf(0.0, env)
	return _new_stream(duration, out)

func _noise(duration: float, amp: float, lp_hz: float) -> AudioStreamWAV:
	var count := int(duration * RATE)
	var out := PackedFloat32Array()
	out.resize(count)
	var prev := 0.0
	var a: float = clampf(TAU * lp_hz / RATE, 0.0, 1.0)
	for i in count:
		var t := float(i) / RATE
		var white := rng.randf_range(-1.0, 1.0)
		prev += (white - prev) * a
		var env := minf(1.0, t / 0.006) * pow(1.0 - t / duration, 2.0)
		out[i] = prev * amp * env
	return _new_stream(duration, out)

func _thump(duration: float, f: float, amp: float) -> AudioStreamWAV:
	var count := int(duration * RATE)
	var out := PackedFloat32Array()
	out.resize(count)
	var phase := 0.0
	for i in count:
		var t := float(i) / RATE
		phase += TAU * f * (1.0 - 0.55 * t / duration) / RATE
		var env := pow(1.0 - t / duration, 2.4)
		out[i] = (sin(phase) * 0.9 + rng.randf_range(-0.08, 0.08)) * amp * env
	return _new_stream(duration, out)

func _arp(notes: Array, step: float, amp: float) -> AudioStreamWAV:
	var duration := step * notes.size() + 0.16
	var count := int(duration * RATE)
	var out := PackedFloat32Array()
	out.resize(count)
	for n in notes.size():
		var start := int(n * step * RATE)
		var freq: float = notes[n]
		var length := int(0.24 * RATE)
		for j in length:
			var idx := start + j
			if idx >= count:
				break
			var t := float(j) / RATE
			var env := minf(1.0, t / 0.004) * pow(maxf(0.0, 1.0 - t / 0.24), 2.0)
			out[idx] += sin(TAU * freq * t) * amp * env
	return _new_stream(duration, out)
