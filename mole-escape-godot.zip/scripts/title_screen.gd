class_name TitleScreen
extends CanvasLayer

signal start_pressed

const FONT_BODY: FontFile = preload("res://assets/fonts/GowunDodum-Regular.ttf")
const FONT_DISPLAY: FontFile = preload("res://assets/fonts/Jua-Regular.ttf")
const CREAM := Color("#f7eed8")
const INK := Color("#3a2c20")
const GOLD := Color("#e4c58a")

var root: Control
var stack: VBoxContainer
var start_button: Button

func _ready() -> void:
	layer = 20
	root = Control.new()
	root.name = "Title"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(root)

	var art := TextureRect.new()
	var tex: Texture2D = load("res://assets/title.svg")
	if tex != null:
		art.texture = tex
	art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(art)

	if tex == null:
		var fallback := ColorRect.new()
		fallback.color = Color("#4d5f78")
		fallback.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		root.add_child(fallback)

	stack = VBoxContainer.new()
	stack.anchor_left = 0.5
	stack.anchor_right = 0.5
	stack.anchor_top = 0.5
	stack.anchor_bottom = 0.5
	stack.offset_left = -400
	stack.offset_right = 400
	stack.offset_top = -282
	stack.offset_bottom = 250
	stack.alignment = BoxContainer.ALIGNMENT_CENTER
	stack.add_theme_constant_override("separation", 4)
	root.add_child(stack)

	var mascot_wrap := CenterContainer.new()
	mascot_wrap.custom_minimum_size = Vector2(0, 122)
	stack.add_child(mascot_wrap)
	var mascot := TextureRect.new()
	var mascot_tex: Texture2D = load("res://assets/mascot.svg")
	mascot.texture = mascot_tex
	mascot.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	mascot.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	mascot.custom_minimum_size = Vector2(118, 118)
	mascot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mascot_wrap.add_child(mascot)

	stack.add_child(_chip("해 지기 전에 탈출하자", 14))

	var title := Label.new()
	title.text = "두더지의 탈출"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_override("font", FONT_DISPLAY)
	title.add_theme_font_size_override("font_size", 84)
	title.add_theme_color_override("font_color", CREAM)
	title.add_theme_color_override("font_outline_color", Color("#4b3720"))
	title.add_theme_constant_override("outline_size", 13)
	title.add_theme_color_override("font_shadow_color", Color(0.56, 0.43, 0.24, 0.9))
	title.add_theme_constant_override("shadow_offset_x", 0)
	title.add_theme_constant_override("shadow_offset_y", 6)
	title.add_theme_constant_override("shadow_outline_size", 2)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stack.add_child(title)

	var en := Label.new()
	en.text = "U N D E R   T H E   B O O T S"
	en.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	en.add_theme_font_override("font", FONT_BODY)
	en.add_theme_font_size_override("font_size", 15)
	en.add_theme_color_override("font_color", Color("#f1e2bd"))
	en.add_theme_color_override("font_outline_color", Color(0.12, 0.09, 0.05, 0.9))
	en.add_theme_constant_override("outline_size", 5)
	stack.add_child(en)

	var invite := Label.new()
	invite.text = "굴 밖으로 나가기"
	invite.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	invite.add_theme_font_override("font", FONT_BODY)
	invite.add_theme_font_size_override("font_size", 16)
	invite.add_theme_color_override("font_color", Color("#f4ecd8"))
	invite.add_theme_color_override("font_outline_color", Color(0.1, 0.08, 0.05, 0.85))
	invite.add_theme_constant_override("outline_size", 5)
	stack.add_child(invite)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 8)
	stack.add_child(spacer)

	start_button = Button.new()
	start_button.text = "S T A R T"
	start_button.custom_minimum_size = Vector2(264, 66)
	start_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	start_button.focus_mode = Control.FOCUS_NONE
	start_button.add_theme_font_override("font", FONT_DISPLAY)
	start_button.add_theme_font_size_override("font_size", 27)
	start_button.add_theme_color_override("font_color", Color("#ffeec6"))
	start_button.add_theme_color_override("font_hover_color", Color("#fff7e0"))
	start_button.add_theme_color_override("font_pressed_color", Color("#ffe3a8"))
	start_button.add_theme_stylebox_override("normal", _start_style(Color("#1e6470")))
	start_button.add_theme_stylebox_override("hover", _start_style(Color("#2b7d88")))
	start_button.add_theme_stylebox_override("pressed", _start_style(Color("#123f49")))
	start_button.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	start_button.pressed.connect(_on_start)
	stack.add_child(start_button)

	var fine := Label.new()
	fine.text = "7개 구간  ·  타임 어택  ·  기록 저장"
	fine.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	fine.add_theme_font_override("font", FONT_BODY)
	fine.add_theme_font_size_override("font_size", 11)
	fine.add_theme_color_override("font_color", Color(0.9, 0.86, 0.75, 0.5))
	stack.add_child(fine)

	_build_guide()
	var frame := FrameArt.new()
	frame.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(frame)

	stack.modulate = Color(1, 1, 1, 0)
	var tw := create_tween()
	tw.tween_property(stack, "modulate", Color.WHITE, 0.55)

func _build_guide() -> void:
	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.08, 0.09, 0.64)
	sb.border_color = Color(0.9, 0.78, 0.55, 0.5)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(12)
	sb.content_margin_left = 18
	sb.content_margin_right = 20
	sb.content_margin_top = 12
	sb.content_margin_bottom = 10
	sb.shadow_color = Color(0, 0, 0, 0.35)
	sb.shadow_size = 8
	panel.add_theme_stylebox_override("panel", sb)
	root.add_child(panel)
	panel.anchor_top = 1.0
	panel.anchor_bottom = 1.0
	panel.offset_left = 120
	panel.offset_right = 380
	panel.offset_top = -170
	panel.offset_bottom = -40
	panel.grow_vertical = Control.GROW_DIRECTION_BEGIN

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 2)
	panel.add_child(col)

	var mobile := OS.has_feature("mobile")
	_guide_row(col, "이동", "좌측 스틱" if mobile else "WASD · 좌측 스틱")
	_guide_row(col, "시점", "우측 드래그" if mobile else "마우스 · 우측 드래그")
	_guide_row(col, "잠수", "파기 버튼" if mobile else "Space · 파기 버튼")
	_guide_row(col, "아이템", "아이템 버튼" if mobile else "F · 아이템 버튼")

	var line := ColorRect.new()
	line.color = Color(0.9, 0.78, 0.55, 0.22)
	line.custom_minimum_size = Vector2(0, 1)
	col.add_child(line)
	var note := Label.new()
	note.text = "7개 구간 · 타임 어택 · 기록 저장"
	note.add_theme_font_override("font", FONT_BODY)
	note.add_theme_font_size_override("font_size", 10)
	note.add_theme_color_override("font_color", Color(0.8, 0.85, 0.8, 0.55))
	col.add_child(note)

func _guide_row(col: VBoxContainer, key: String, value: String) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	col.add_child(row)
	var k := Label.new()
	k.text = key
	k.custom_minimum_size = Vector2(46, 0)
	k.add_theme_font_override("font", FONT_DISPLAY)
	k.add_theme_font_size_override("font_size", 13)
	k.add_theme_color_override("font_color", Color("#ffd991"))
	row.add_child(k)
	var v := Label.new()
	v.text = value
	v.add_theme_font_override("font", FONT_BODY)
	v.add_theme_font_size_override("font_size", 12)
	v.add_theme_color_override("font_color", Color(0.9, 0.94, 0.9, 0.82))
	row.add_child(v)

func _chip(text: String, font_size: int) -> Control:
	var wrap := CenterContainer.new()
	wrap.custom_minimum_size = Vector2(0, 30)
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.09, 0.07, 0.05, 0.55)
	sb.border_color = Color(0.9, 0.78, 0.55, 0.55)
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(20)
	sb.content_margin_left = 16
	sb.content_margin_right = 16
	sb.content_margin_top = 5
	sb.content_margin_bottom = 5
	p.add_theme_stylebox_override("panel", sb)
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", FONT_BODY)
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color("#f6e5bf"))
	l.add_theme_color_override("font_outline_color", Color(0.08, 0.06, 0.04, 0.8))
	l.add_theme_constant_override("outline_size", 4)
	p.add_child(l)
	wrap.add_child(p)
	return wrap

func _start_style(color: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.border_color = GOLD
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(12)
	sb.shadow_color = Color(0.05, 0.04, 0.02, 0.6)
	sb.shadow_size = 10
	sb.shadow_offset = Vector2(0, 6)
	sb.anti_aliasing = true
	return sb

func _on_start() -> void:
	start_button.disabled = true
	start_pressed.emit()

func hide_menu() -> void:
	visible = false

func show_menu() -> void:
	visible = true
	start_button.disabled = false

# ---------------------------------------------------------------- frame art

class FrameArt:
	extends Control
	func _draw() -> void:
		var w := size.x
		var h := size.y
		draw_rect(Rect2(0, 0, w, h), Color("#241809"), false, 10.0)
		draw_rect(Rect2(5, 5, w - 10, h - 10), Color("#6d4a2b"), false, 5.0)
		draw_rect(Rect2(10, 10, w - 20, h - 20), Color("#8d6438"), false, 4.0)
		draw_rect(Rect2(14, 14, w - 28, h - 28), Color("#5a3d22"), false, 4.0)
		draw_rect(Rect2(18, 18, w - 36, h - 36), Color("#2a1c0f"), false, 3.0)
		# metal corner plates
		for p in [Vector2(4, 4), Vector2(w - 46, 4), Vector2(4, h - 46), Vector2(w - 46, h - 46)]:
			var r := Rect2(p, Vector2(42, 42))
			draw_rect(r, Color("#596166"))
			draw_rect(r, Color("#24292d"), false, 2.0)
			draw_rect(Rect2(p + Vector2(4, 4), Vector2(34, 34)), Color(1, 1, 1, 0.08), false, 1.0)
			draw_circle(p + Vector2(10, 10), 3.0, Color("#d9e0e3"))
			draw_circle(p + Vector2(32, 32), 3.0, Color("#d9e0e3"))
		# inner vignette hints
		draw_rect(Rect2(1, 1, w - 2, h - 2), Color(0, 0, 0, 0.25), false, 2.0)
