class_name TouchControls
extends Control

## Full-screen touch layer:
##   left half  -> floating movement stick
##   right half -> drag to look
## The four action buttons live above this layer in the HUD.

signal item_pressed

var enabled := false
var move := Vector2.ZERO
var look := Vector2.ZERO
var dig_held := false

var joy_index := -1
var look_index := -1
var dig_index := -1
var dig_mouse := false
var joy_origin := Vector2.ZERO
var knob := Vector2.ZERO
var last_look := Vector2.ZERO
var max_radius := 58.0
var appearance := 0.0
var touch_device := false

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	touch_device = DisplayServer.is_touchscreen_available()

func dig_center() -> Vector2:
	return Vector2(size.x - 174.0, size.y - 104.0)

func item_center() -> Vector2:
	return Vector2(size.x - 282.0, size.y - 88.0)

func set_enabled(on: bool) -> void:
	enabled = on
	if not on:
		_reset()

func _reset() -> void:
	joy_index = -1
	look_index = -1
	dig_index = -1
	dig_mouse = false
	move = Vector2.ZERO
	knob = Vector2.ZERO
	dig_held = false
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if not enabled:
		return

	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.distance_to(dig_center()) < 58.0 and dig_index == -1 and dig_mouse == false:
				dig_index = event.index
				dig_held = true
				accept_event()
				return
			if event.position.distance_to(item_center()) < 42.0:
				item_pressed.emit()
				accept_event()
				return
			if event.position.x < size.x * 0.48 and joy_index == -1:
				joy_index = event.index
				joy_origin = event.position
				knob = Vector2.ZERO
				appearance = 1.0
			elif look_index == -1:
				look_index = event.index
				last_look = event.position
		else:
			if event.index == joy_index:
				joy_index = -1
				move = Vector2.ZERO
				knob = Vector2.ZERO
			if event.index == look_index:
				look_index = -1
			if event.index == dig_index:
				dig_index = -1
				dig_held = false
		queue_redraw()
		accept_event()
		return

	if event is InputEventScreenDrag:
		if event.index == joy_index:
			var d: Vector2 = event.position - joy_origin
			if d.length() > max_radius:
				d = d.normalized() * max_radius
			knob = d
			move = Vector2(d.x, -d.y) / max_radius
			queue_redraw()
			accept_event()
		elif event.index == look_index:
			var d: Vector2 = event.position - last_look
			last_look = event.position
			look += d * 0.0042
			accept_event()
		elif event.index == dig_index:
			accept_event()
		return

	# Desktop mouse. Touch devices use the ScreenTouch path above; the emulated
	# mouse events that Godot generates for UI buttons are left alone.
	if touch_device:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			if event.position.distance_to(dig_center()) < 58.0:
				dig_mouse = true
				dig_held = true
				accept_event()
				return
			if event.position.distance_to(item_center()) < 42.0:
				item_pressed.emit()
				accept_event()
				return
			look_index = -2
			last_look = event.position
		elif look_index == -2:
			look_index = -1
		elif dig_mouse:
			dig_mouse = false
			dig_held = false
		return
	if event is InputEventMouseMotion and look_index == -2:
		look += event.relative * 0.0026
		return

func consume_look() -> Vector2:
	var out := look
	look = Vector2.ZERO
	return out

func _draw() -> void:
	if not enabled:
		return
	var base_center := Vector2(170, size.y - 118)
	if joy_index != -1:
		base_center = joy_origin
		var ring_col := Color(0.96, 0.9, 0.76, 0.28)
		draw_circle(base_center, max_radius + 6.0, Color(0.06, 0.08, 0.06, 0.22))
		draw_arc(base_center, max_radius, 0.0, TAU, 48, ring_col, 2.0, true)
		draw_arc(base_center, max_radius * 0.45, 0.0, TAU, 32, Color(0.96, 0.9, 0.76, 0.13), 1.5, true)
		draw_circle(base_center + knob, 25.0, Color(0.95, 0.87, 0.7, 0.55))
		draw_arc(base_center + knob, 25.0, 0.0, TAU, 32, Color(0.28, 0.2, 0.12, 0.55), 2.0, true)
	else:
		draw_arc(base_center, max_radius, 0.0, TAU, 40, Color(0.96, 0.9, 0.76, 0.13), 1.5, true)
		draw_circle(base_center, 18.0, Color(0.96, 0.9, 0.76, 0.06))
