class_name MoleModel
extends Node3D

## Low-poly mole built from primitives, matching the web model.

const FUR := Color(0.478, 0.373, 0.286)
const FUR_DARK := Color(0.392, 0.294, 0.224)
const BELLY := Color(0.902, 0.796, 0.651)
const SKIN := Color(0.929, 0.663, 0.561)
const NOSE := Color(0.788, 0.439, 0.435)
const CLAW := Color(0.945, 0.906, 0.824)
const EYE := Color(0.165, 0.129, 0.102)

var body: Node3D
var head: MeshInstance3D
var snout: Node3D
var arms: Array[Node3D] = []
var feet: Array[MeshInstance3D] = []
var tail: MeshInstance3D
var leaf: Node3D
var eyes: Array[MeshInstance3D] = []
var shadow: MeshInstance3D
var fur_mat: StandardMaterial3D
var belly_mat: StandardMaterial3D
var skin_mat: StandardMaterial3D

var idle_t := 0.0
var anim_phase := 0.0
var base_tail := -0.85

func _ready() -> void:
	_build()

func _build() -> void:
	fur_mat = _make_mat(FUR, 0.84)
	belly_mat = _make_mat(BELLY, 0.8)
	skin_mat = _make_mat(SKIN, 0.72)
	var fur_dark := _make_mat(FUR_DARK, 0.9)
	var nose_mat := _make_mat(NOSE, 0.55)
	var claw_mat := _make_mat(CLAW, 0.42)
	var eye_mat := _make_mat(EYE, 0.2, 0.15)
	var shine_mat := _make_mat(Color.WHITE, 0.3)
	var leaf_mat := _make_mat(Color(0.482, 0.639, 0.329), 0.75)
	var stem_mat := _make_mat(Color(0.310, 0.443, 0.196), 0.85)

	body = Node3D.new()
	body.name = "Body"
	add_child(body)

	var torso := _sphere(body, Vector3(0, 0.118, 0.02), 0.11, fur_mat, Vector3(1, 0.94, 1.32))
	torso.name = "Torso"
	_sphere(body, Vector3(0, 0.088, -0.055), 0.083, belly_mat, Vector3(0.86, 0.78, 1.08))

	head = _sphere(body, Vector3(0, 0.176, -0.098), 0.086, fur_mat, Vector3(1, 0.96, 1))
	head.name = "Head"

	snout = Node3D.new()
	snout.position = Vector3(0, 0.148, -0.172)
	body.add_child(snout)
	_sphere(snout, Vector3.ZERO, 0.045, skin_mat, Vector3(1.16, 0.84, 1.22))
	_sphere(snout, Vector3(0, 0.011, -0.043), 0.018, nose_mat, Vector3(1.25, 1, 1))
	for side in [-1.0, 1.0]:
		for i in 2:
			var whisker := _cylinder(snout, Vector3(side * 0.046, 0.004 + i * 0.013, 0.008), 0.0012, 0.062, fur_dark, 0.0012, 0.0012, 4)
			whisker.rotation.z = PI * 0.5
			whisker.rotation.y = side * (0.32 + i * 0.26)

	for sx in [-0.038, 0.038]:
		var eye := _sphere(body, Vector3(sx, 0.192, -0.158), 0.021, eye_mat)
		eyes.append(eye)
		_sphere(body, Vector3(sx + 0.006, 0.2, -0.175), 0.0068, shine_mat, Vector3.ONE, 8, 6, false)

	for sx in [-0.062, 0.062]:
		_sphere(body, Vector3(sx, 0.248, -0.072), 0.021, skin_mat, Vector3(1, 1, 0.42), 10, 8)

	leaf = Node3D.new()
	leaf.position = Vector3(0.015, 0.248, -0.095)
	body.add_child(leaf)
	_cylinder(leaf, Vector3(0, 0.022, 0), 0.0035, 0.045, stem_mat, 0.0035, 0.0035, 5)
	var blade := _sphere(leaf, Vector3(0.02, 0.047, 0), 0.03, leaf_mat, Vector3(1.5, 0.22, 0.75), 10, 8)
	blade.rotation.z = 0.35

	for side in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(side * 0.086, 0.12, -0.12)
		body.add_child(pivot)
		var upper := _capsule(pivot, Vector3(side * 0.012, -0.022, 0), 0.019, 0.083, fur_mat)
		upper.rotation.z = side * 0.55
		var paw := _sphere(pivot, Vector3(side * 0.033, -0.05, -0.012), 0.029, skin_mat, Vector3(1.2, 0.5, 1.35), 12, 10)
		paw.name = "Paw"
		for i in 3:
			var claw := _cylinder(pivot, Vector3(side * 0.033 + (i - 1) * 0.0095, -0.052, -0.05), 0.0048, 0.026, claw_mat, 0.0, 0.0048, 5)
			claw.rotation.x = -PI * 0.5
		arms.append(pivot)

	for side in [-1.0, 1.0]:
		var foot := _sphere(body, Vector3(side * 0.06, 0.022, 0.092), 0.031, skin_mat, Vector3(1.1, 0.42, 1.55), 12, 10)
		feet.append(foot)

	tail = _cylinder(body, Vector3(0, 0.128, 0.188), 0.017, 0.068, skin_mat, 0.0, 0.017, 8)
	tail.rotation.x = base_tail

	# Soft contact shadow (no texture required).
	shadow = _sphere(self, Vector3(0, 0.008, 0), 0.22, _make_mat(Color(0.02, 0.015, 0.01), 1.0, 0.0, 0.5), Vector3(1.0, 0.02, 1.18), 14, 8, false)
	shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	for m in [fur_mat, belly_mat, skin_mat]:
		m.emission_enabled = true
		m.emission = Color(1.0, 0.35, 0.235)
		m.emission_energy_multiplier = 0.0

func animate(dt: float, state: String, state_t: float, moving: float, sprint: bool, dig_phase: float, dead: bool, hurt: float, buff: bool) -> void:
	idle_t += dt
	if state == "under":
		visible = false
		return
	visible = true
	shadow.visible = state != "diving" and not dead

	if state == "rising":
		var t: float = clampf(state_t / 0.28, 0.0, 1.0)
		scale = Vector3.ONE * (0.6 + 0.4 * t)
		position.y = -0.04 * (1.0 - t)
	elif state == "diving":
		var t: float = clampf(state_t / 0.34, 0.0, 1.0)
		scale = Vector3.ONE * (1.0 - t * 0.25)
		position.y = -0.06 * t
	else:
		scale = Vector3.ONE
		position.y = 0.0

	leaf.rotation.z = sin(idle_t * 1.4) * 0.16
	snout.rotation.x = sin(idle_t * 2.6) * 0.035
	snout.rotation.y = sin(idle_t * 0.8) * 0.04
	tail.rotation.x = base_tail + sin(idle_t * 2.2) * 0.06

	if dead:
		body.rotation.z = lerpf(body.rotation.z, -1.35, minf(1.0, dt * 6.0))
		body.rotation.x = lerpf(body.rotation.x, 0.2, minf(1.0, dt * 6.0))
		body.position.y = lerpf(body.position.y, -0.02, minf(1.0, dt * 6.0))
		_set_hurt(0.0)
		return

	if state == "diving":
		body.rotation.z = sin(dig_phase) * 0.12
		body.rotation.x = 0.35 + sin(dig_phase * 0.5) * 0.1
		body.position.y = -0.02 + sin(dig_phase) * 0.01
		arms[0].rotation.x = sin(dig_phase) * 1.1
		arms[1].rotation.x = sin(dig_phase + PI) * 1.1
		_set_hurt(hurt)
		return

	var walking: bool = moving > 0.06 and state == "surface"
	anim_phase += dt * (15.0 if (walking and sprint) else 10.0 if walking else 2.2)
	var swing: float = sin(anim_phase) if walking else 0.0

	body.rotation.x = absf(swing) * 0.06 if walking else sin(idle_t * 1.6) * 0.02
	body.rotation.z = swing * 0.1 if walking else sin(idle_t * 0.9) * 0.015
	body.position.y = absf(swing) * 0.013 if walking else sin(idle_t * 2.1) * 0.004

	arms[0].rotation.x = swing * 0.9 if walking else sin(idle_t * 1.7) * 0.07
	arms[1].rotation.x = -swing * 0.9 if walking else sin(idle_t * 1.7 + 1.2) * 0.07
	arms[0].rotation.z = sin(idle_t * 1.3) * 0.03
	arms[1].rotation.z = -sin(idle_t * 1.3) * 0.03

	feet[0].position.z = 0.092 + (swing * 0.017 if walking else 0.0)
	feet[1].position.z = 0.092 - (swing * 0.017 if walking else 0.0)

	if buff:
		leaf.rotation.z += sin(anim_phase * 1.5) * 0.12

	_set_hurt(hurt)

func _set_hurt(v: float) -> void:
	for m in [fur_mat, belly_mat, skin_mat]:
		m.emission_energy_multiplier = v * 0.7

func _make_mat(c: Color, rough: float, metal := 0.0, alpha := 1.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(c.r, c.g, c.b, alpha)
	m.roughness = rough
	m.metallic = metal
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return m

func _sphere(parent: Node3D, pos: Vector3, radius: float, mat: Material, scl := Vector3.ONE, segs := 16, rings := 10, shadows := true) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = segs
	mesh.rings = rings
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.scale = scl
	if not shadows:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi

func _capsule(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material) -> MeshInstance3D:
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = maxf(height, radius * 2.01)
	mesh.radial_segments = 8
	mesh.rings = 4
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi

func _cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material, top := -1.0, bottom := -1.0, segs := 8) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius if top < 0.0 else top
	mesh.bottom_radius = radius if bottom < 0.0 else bottom
	mesh.height = height
	mesh.radial_segments = segs
	mesh.rings = 1
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi
