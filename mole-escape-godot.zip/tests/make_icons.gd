extends SceneTree
func _initialize() -> void:
	var tex: Texture2D = load("res://icon.svg")
	var img := tex.get_image()
	if img == null:
		printerr("ICON_IMAGE_MISSING")
		quit(1)
		return
	for s in [1024, 512, 180, 167, 152, 120, 87, 80, 76, 60, 58, 40, 29, 20]:
		var out := img.duplicate() as Image
		out.resize(s, s, Image.INTERPOLATE_LANCZOS)
		if out.is_compressed():
			out.decompress()
		out.convert(Image.FORMAT_RGB8)
		out.save_png("res://assets/ios/AppIcon-%d.png" % s)
	print("ICONS_OK 1024..20")
	quit()
