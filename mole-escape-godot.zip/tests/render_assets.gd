extends SceneTree

## Saves rasterised SVG imports so the title art can be inspected without a GPU.
##   godot --headless --path godot --script res://tests/render_assets.gd

func _initialize() -> void:
	for pair in [["title", "res://assets/title.svg"], ["mascot", "res://assets/mascot.svg"], ["icon", "res://icon.svg"]]:
		var tex: Texture2D = load(pair[1])
		if tex == null:
			printerr("MISSING ", pair[1])
			continue
		var img := tex.get_image()
		if img == null:
			printerr("NO_IMAGE ", pair[1])
			continue
		var path := "res://tests/_%s.png" % pair[0]
		img.save_png(path)
		print("RASTER ", pair[0], " ", tex.get_width(), "x", tex.get_height(), " -> ", path)
	quit()
