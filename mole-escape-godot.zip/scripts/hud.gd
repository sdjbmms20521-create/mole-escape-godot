class_name GameHUD
extends CanvasLayer

## Paper-and-sticker HUD, touch buttons, shop, death and ending screens.

signal buy_requested(id: String)
signal depart_requested
signal retry_requested
signal restart_requested
signal item_pressed

const FONT_BODY: FontFile = preload("res://assets/fonts/GowunDodum-Regular.ttf")
const FONT_DISPLAY: FontFile = preload("res://assets/fonts/Jua-Regular.ttf")

const INK := Color("#3a2c20")
const INK_SOFT := Color("#6b5a45")
const PAPER := Color("#f4ead2")
const PAPER_DEEP := Color("#e9dabd")
const CREAM := Color("#fdf6e5")
const GOLD := Color("#b98c46")
const TEAL := Color("#1e6470")
const TEAL_DARK := Color("#123f49")
const RED := Color("#a83a2c")
const GREEN := Color("#5f8a44")
const BLUE := Color("#4d8fa8")

var root: Control
var hud_root: Control
var overlay_root: Control
var touch: TouchControls
var fx_damage: ColorRect
var fx_under: ColorRect

var scrap_label: Label
var distance_label: Label
var time_label: Label
var hearts: Array = []
var health_pill: PanelContainer
var oxygen_pill: PanelContainer
var oxygen_bar: ProgressBar
var buff_pill: PanelContainer
var dig_btn: Button
var dig_label: Label
var dig_cd: Label
var dig_paw: PawIcon
var item_btn: Button
var item_label: Label
var item_count: Label
var nav_panel: PanelContainer
var nav_arrow: NavArrow
var nav_label: Label
var objective_panel: PanelContainer
var objective_label: Label
var hint_panel: PanelContainer
var hint_label: Label

var dig_available := true
var dig_held_visual := false
var objective_until := 0
var hint_until := 0
var damage_alpha := 0.0
var danger_level := 0.0
var under_amount := 0.0
var under_target := 0.0

func setup() -> void:
	layer = 10
	root = Control.new()
	root.name = "HUD"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var theme := Theme.new()
	theme.default_font = FONT_BODY
	theme.default_font_size = 16
	root.theme = theme
	add_child(root)

	fx_under = ColorRect.new()
	fx_under.color = Color(0.02, 0.05, 0.02, 0.0)
	fx_under.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fx_under.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(fx_under)

	fx_damage = ColorRect.new()
	fx_damage.color = Color(0.6, 0.05, 0.02, 0.0)
	fx_damage.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fx_damage.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(fx_damage)

	touch = TouchControls.new()
	touch.name = "Touch"
	touch.item_pressed.connect(_on_item_pressed)
	root.add_child(touch)

	hud_root = Control.new()
	hud_root.name = "PlayingHUD"
	hud_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud_root)
	_build_playing_hud()

	overlay_root = Control.new()
	overlay_root.name = "Overlays"
	overlay_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay_root.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay_root.visible = false
	root.add_child(overlay_root)

	hud_root.visible = false

func _process(delta: float) -> void:
	var now := Time.get_ticks_msec()
	if objective_until > 0 and now > objective_until:
		objective_until = 0
		objective_panel.visible = false
	if hint_until > 0 and now > hint_until:
		hint_until = 0
		hint_panel.visible = false

	damage_alpha = maxf(0.0, damage_alpha - delta * 1.8)
	fx_damage.color = Color(0.62, 0.06, 0.02, damage_alpha + danger_level * 0.1)
	under_amount = lerpf(under_amount, under_target, minf(1.0, delta * 6.0))
	fx_under.color = Color(0.02, 0.05, 0.02, under_amount * 0.26)
	if under_target <= 0.0 and under_amount < 0.01:
		under_amount = 0.0
	if touch.dig_held != dig_held_visual:
		dig_held_visual = touch.dig_held
		_apply_dig_modulate()

# ---------------------------------------------------------------- build

func _build_playing_hud() -> void:
	var left := VBoxContainer.new()
	left.position = Vector2(120, 16)
	left.add_theme_constant_override("separation", 6)
	hud_root.add_child(left)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	left.add_child(row)

	var scrap_pill := _pill()
	var srow := HBoxContainer.new()
	srow.add_theme_constant_override("separation", 6)
	scrap_pill.add_child(srow)
	srow.add_child(CoinIcon.new())
	scrap_label = _label("0", 17, INK)
	srow.add_child(scrap_label)
	row.add_child(scrap_pill)

	var dist_pill := _pill(Color(0.965, 0.93, 0.855, 0.82))
	var drow := HBoxContainer.new()
	drow.add_theme_constant_override("separation", 6)
	dist_pill.add_child(drow)
	drow.add_child(DistanceIcon.new())
	distance_label = _label("-- m", 16, INK)
	drow.add_child(distance_label)
	row.add_child(dist_pill)

	health_pill = _pill()
	var hrow := HBoxContainer.new()
	hrow.add_theme_constant_override("separation", 4)
	health_pill.add_child(hrow)
	hearts.clear()
	for i in 3:
		var meter := HeartMeter.new()
		hrow.add_child(meter)
		hearts.append(meter)
	left.add_child(health_pill)

	oxygen_pill = _pill(Color(0.93, 0.955, 0.96, 0.92))
	var orow := HBoxContainer.new()
	orow.add_theme_constant_override("separation", 7)
	oxygen_pill.add_child(orow)
	orow.add_child(BreathIcon.new())
	oxygen_bar = ProgressBar.new()
	oxygen_bar.min_value = 0
	oxygen_bar.max_value = 100
	oxygen_bar.value = 100
	oxygen_bar.show_percentage = false
	oxygen_bar.custom_minimum_size = Vector2(118, 8)
	oxygen_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	oxygen_bar.add_theme_stylebox_override("background", _bar_bg())
	oxygen_bar.add_theme_stylebox_override("fill", _bar_fill(BLUE))
	orow.add_child(oxygen_bar)
	var breath := _label("숨", 12, INK_SOFT)
	orow.add_child(breath)
	oxygen_pill.visible = false
	left.add_child(oxygen_pill)

	buff_pill = _chip()
	var buff_label := _label("질주 중", 12, Color("#ffd991"))
	buff_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	buff_pill.add_child(buff_label)
	buff_pill.visible = false
	left.add_child(buff_pill)

	var timer_pill := _pill()
	var trow := HBoxContainer.new()
	trow.add_theme_constant_override("separation", 6)
	timer_pill.add_child(trow)
	trow.add_child(ClockIcon.new())
	time_label = _label("0:00", 17, INK)
	trow.add_child(time_label)
	hud_root.add_child(timer_pill)
	timer_pill.anchor_left = 1.0
	timer_pill.anchor_right = 1.0
	timer_pill.offset_left = -226
	timer_pill.offset_right = -120
	timer_pill.offset_top = 16
	timer_pill.offset_bottom = 46
	timer_pill.grow_horizontal = Control.GROW_DIRECTION_BEGIN

	objective_panel = _chip()
	objective_label = _label("", 16, CREAM)
	objective_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	objective_panel.add_child(objective_label)
	objective_panel.anchor_left = 0.5
	objective_panel.anchor_right = 0.5
	objective_panel.offset_left = -280
	objective_panel.offset_right = 280
	objective_panel.offset_top = 16
	objective_panel.offset_bottom = 50
	objective_panel.visible = false
	hud_root.add_child(objective_panel)

	nav_panel = _pill(Color(0.09, 0.14, 0.1, 0.72))
	var nrow := HBoxContainer.new()
	nrow.add_theme_constant_override("separation", 6)
	nav_panel.add_child(nrow)
	nav_arrow = NavArrow.new()
	nrow.add_child(nav_arrow)
	nav_label = _label("", 14, Color("#f7e9c6"))
	nrow.add_child(nav_label)
	nav_panel.anchor_left = 0.5
	nav_panel.anchor_right = 0.5
	nav_panel.offset_left = -92
	nav_panel.offset_right = 92
	nav_panel.offset_top = 58
	nav_panel.offset_bottom = 88
	nav_panel.visible = false
	hud_root.add_child(nav_panel)

	hint_panel = _chip()
	hint_label = _label("", 15, CREAM)
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint_panel.add_child(hint_label)
	hint_panel.anchor_left = 0.5
	hint_panel.anchor_right = 0.5
	hint_panel.anchor_top = 1.0
	hint_panel.anchor_bottom = 1.0
	hint_panel.offset_left = -300
	hint_panel.offset_right = 300
	hint_panel.offset_top = -180
	hint_panel.offset_bottom = -140
	hint_panel.visible = false
	hud_root.add_child(hint_panel)

	# item button
	item_btn = Button.new()
	item_btn.focus_mode = Control.FOCUS_NONE
	item_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	item_btn.text = ""
	item_btn.anchor_left = 1.0
	item_btn.anchor_right = 1.0
	item_btn.anchor_top = 1.0
	item_btn.anchor_bottom = 1.0
	item_btn.offset_left = -320
	item_btn.offset_right = -244
	item_btn.offset_top = -126
	item_btn.offset_bottom = -50
	item_btn.add_theme_stylebox_override("normal", _round_style(Color(0.16, 0.22, 0.18, 0.92), Color(0.93, 0.83, 0.63, 0.8), 42))
	item_btn.add_theme_stylebox_override("hover", _round_style(Color(0.21, 0.29, 0.23, 0.95), Color(0.93, 0.83, 0.63), 42))
	item_btn.add_theme_stylebox_override("pressed", _round_style(Color(0.11, 0.16, 0.13, 0.96), Color(0.93, 0.83, 0.63), 42))
	item_btn.add_theme_stylebox_override("disabled", _round_style(Color(0.18, 0.2, 0.18, 0.6), Color(0.6, 0.55, 0.45, 0.5), 42))
	item_btn.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	hud_root.add_child(item_btn)
	var bottle := BottleIcon.new()
	bottle.position = Vector2(25, 12)
	bottle.size = Vector2(26, 26)
	item_btn.add_child(bottle)
	item_label = _label("아이템", 12, Color("#f3e7c9"))
	item_label.position = Vector2(0, 40)
	item_label.size = Vector2(76, 18)
	item_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	item_btn.add_child(item_label)
	item_count = _label("없음", 10, Color(0.93, 0.83, 0.63, 0.8))
	item_count.position = Vector2(0, 56)
	item_count.size = Vector2(76, 16)
	item_count.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	item_btn.add_child(item_count)

	# dig button
	dig_btn = Button.new()
	dig_btn.focus_mode = Control.FOCUS_NONE
	dig_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dig_btn.text = ""
	dig_btn.anchor_left = 1.0
	dig_btn.anchor_right = 1.0
	dig_btn.anchor_top = 1.0
	dig_btn.anchor_bottom = 1.0
	dig_btn.offset_left = -228
	dig_btn.offset_right = -120
	dig_btn.offset_top = -158
	dig_btn.offset_bottom = -50
	dig_btn.add_theme_stylebox_override("normal", _round_style(Color("#f4e4c2"), Color("#3a2c20"), 62))
	dig_btn.add_theme_stylebox_override("hover", _round_style(Color("#fbeed0"), Color("#3a2c20"), 62))
	dig_btn.add_theme_stylebox_override("pressed", _round_style(Color("#e4d0a8"), Color("#3a2c20"), 62))
	dig_btn.add_theme_stylebox_override("disabled", _round_style(Color("#cfc3a8"), Color("#6a5a44"), 62))
	dig_btn.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	dig_btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_root.add_child(dig_btn)
	dig_paw = PawIcon.new()
	dig_paw.position = Vector2(34, 18)
	dig_paw.size = Vector2(40, 40)
	dig_btn.add_child(dig_paw)
	dig_label = _label("파기", 16, INK)
	dig_label.position = Vector2(0, 58)
	dig_label.size = Vector2(108, 24)
	dig_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dig_btn.add_child(dig_label)
	dig_cd = _label("", 22, RED)
	dig_cd.position = Vector2(74, 6)
	dig_cd.size = Vector2(30, 30)
	dig_cd.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dig_cd.visible = false
	dig_btn.add_child(dig_cd)

	# The action buttons are drawn for feedback, but touches are tracked by the
	# full-screen TouchControls layer underneath. Child icons/labels must not
	# swallow those touches.
	_ignore_mouse(item_btn)
	_ignore_mouse(dig_btn)

func _ignore_mouse(node: Node) -> void:
	for child in node.get_children():
		if child is Control:
			(child as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
		_ignore_mouse(child)

func _on_item_pressed() -> void:
	if not item_btn.disabled:
		item_pressed.emit()

# ---------------------------------------------------------------- updates

func set_health(value: float) -> void:
	# Health still runs 0-100 internally; the three hearts show it as a
	# fraction each, so damage keeps the same feel as before.
	var ratio := clampf(value / 100.0, 0.0, 1.0)
	var count := hearts.size()
	for i in count:
		var part: float = clampf(ratio * float(count) - float(i), 0.0, 1.0)
		hearts[i].set_fill(part)

func flash_damage() -> void:
	damage_alpha = 0.34
	var tw := create_tween()
	health_pill.pivot_offset = health_pill.size * 0.5
	tw.tween_property(health_pill, "scale", Vector2(1.07, 1.12), 0.06)
	tw.tween_property(health_pill, "scale", Vector2.ONE, 0.16)

func set_oxygen(value: float, underground: bool) -> void:
	oxygen_bar.value = value * 100.0
	oxygen_pill.visible = underground or value < 0.995
	if value < 0.32:
		oxygen_bar.add_theme_stylebox_override("fill", _bar_fill(Color("#c2553b")))
	elif value < 0.6:
		oxygen_bar.add_theme_stylebox_override("fill", _bar_fill(Color("#d0a13c")))
	else:
		oxygen_bar.add_theme_stylebox_override("fill", _bar_fill(BLUE))

func set_scrap(n: int) -> void:
	scrap_label.text = str(n)

func set_time(seconds: float) -> void:
	time_label.text = MoleData.fmt_clock(seconds)

func set_distance(meters: float) -> void:
	distance_label.text = "%d m" % int(round(meters))

func set_dig(burrowable: bool, underground: bool, cooldown: float) -> void:
	if underground:
		dig_label.text = "올라오기"
	elif not burrowable:
		dig_label.text = "불가"
	else:
		dig_label.text = "파기"
	dig_available = burrowable or underground
	_apply_dig_modulate()
	if cooldown > 0.05:
		dig_cd.visible = true
		dig_cd.text = str(int(ceil(cooldown)))
		dig_paw.modulate = Color(1, 1, 1, 0.35)
	else:
		dig_cd.visible = false
		dig_paw.modulate = Color.WHITE

func _apply_dig_modulate() -> void:
	var alpha := 1.0 if dig_available else 0.84
	var bright := 0.9 if touch.dig_held else 1.0
	dig_btn.modulate = Color(bright, bright, bright, alpha)

func set_buff_visual(on: bool) -> void:
	buff_pill.visible = on

func set_item(text: String, count: int, disabled: bool) -> void:
	item_label.text = text
	item_count.text = "없음" if count <= 0 else "×%d" % count
	item_btn.disabled = disabled
	item_btn.modulate = Color(0.8, 0.8, 0.8, 0.8) if disabled else Color.WHITE

func set_objective(text: String, ms: int) -> void:
	objective_label.text = text
	objective_panel.visible = true
	objective_until = Time.get_ticks_msec() + ms

func hint(text: String, ms: int) -> void:
	hint_label.text = text
	hint_panel.visible = true
	hint_until = Time.get_ticks_msec() + ms

func set_nav(angle_deg: Variant, dist := 0.0) -> void:
	if angle_deg == null:
		nav_panel.visible = false
		return
	nav_panel.visible = true
	nav_arrow.rotation = deg_to_rad(float(angle_deg))
	nav_label.text = "%d m" % int(round(dist))

func set_danger(level: float) -> void:
	danger_level = clampf(level, 0.0, 1.0)

func set_underground(on: bool) -> void:
	under_target = 1.0 if on else 0.0

func show_game() -> void:
	hud_root.visible = true
	overlay_root.visible = false
	touch.set_enabled(true)
	danger_level = 0.0

func hide_game() -> void:
	hud_root.visible = false
	touch.set_enabled(false)
	dig_held_visual = false

# ---------------------------------------------------------------- shop

func show_shop(info: Dictionary) -> void:
	_clear_overlay()
	hud_root.visible = false
	touch.set_enabled(false)
	overlay_root.visible = true

	var dim := ColorRect.new()
	dim.color = Color(0.03, 0.05, 0.04, 0.74)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay_root.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay_root.add_child(center)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(980, 548)
	panel.add_theme_stylebox_override("panel", _paper_style(PAPER, INK, 3, 20, 8))
	center.add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 22)
	margin.add_theme_constant_override("margin_bottom", 18)
	panel.add_child(margin)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	margin.add_child(col)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 20)
	col.add_child(header)
	var info_col := VBoxContainer.new()
	info_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info_col.add_theme_constant_override("separation", 2)
	header.add_child(info_col)

	var eyebrow := _label("삐죽 영감의 잡화점   ·   %d / %d" % [int(info.get("index", 0)) + 1, int(info.get("total", 7))], 13, GOLD)
	info_col.add_child(eyebrow)
	var name_label := _label(str(info.get("name", "")), 34, INK, FONT_DISPLAY)
	info_col.add_child(name_label)
	info_col.add_child(_label(str(info.get("sub", "")), 14, INK_SOFT))
	var brief := _label(str(info.get("brief", "")), 14, Color("#4c3b2a"))
	brief.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	brief.custom_minimum_size = Vector2(640, 44)
	info_col.add_child(brief)
	var best: float = float(info.get("best", -1.0))
	var record_text := "이 구간 최고 기록 %s" % MoleData.fmt_time(best) if best >= 0.0 else "이 구간 첫 도전"
	info_col.add_child(_label(record_text, 13, GOLD))

	var wallet := PanelContainer.new()
	wallet.add_theme_stylebox_override("panel", _paper_style(Color("#efe0bf"), GOLD, 2, 12, 0))
	wallet.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	header.add_child(wallet)
	var wallet_row := HBoxContainer.new()
	wallet_row.add_theme_constant_override("separation", 8)
	wallet.add_child(wallet_row)
	wallet_row.add_child(CoinIcon.new())
	var wallet_label := _label(str(int(info.get("scrap", 0))), 26, INK, FONT_DISPLAY)
	wallet_row.add_child(wallet_label)
	var wallet_word := _label("폐품", 12, INK_SOFT)
	wallet_word.size_flags_vertical = Control.SIZE_SHRINK_END
	wallet_row.add_child(wallet_word)

	var cards := HBoxContainer.new()
	cards.add_theme_constant_override("separation", 12)
	cards.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(cards)

	var charges: Dictionary = info.get("charges", {})
	var equipped: Array = info.get("equipped", [])
	for id in ["helmet", "drink", "nav"]:
		var item: Dictionary = MoleData.ITEMS[id]
		var card := PanelContainer.new()
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.add_theme_stylebox_override("panel", _paper_style(Color("#f0e3c8"), Color("#7d6749"), 2, 14, 0))
		cards.add_child(card)
		var cm := MarginContainer.new()
		cm.add_theme_constant_override("margin_left", 15)
		cm.add_theme_constant_override("margin_right", 15)
		cm.add_theme_constant_override("margin_top", 12)
		cm.add_theme_constant_override("margin_bottom", 12)
		card.add_child(cm)
		var cv := VBoxContainer.new()
		cv.add_theme_constant_override("separation", 3)
		cm.add_child(cv)
		cv.add_child(_label(str(item["name"]), 22, INK, FONT_DISPLAY))
		cv.add_child(_label(str(item["tag"]), 12, TEAL))
		var desc := _label(str(item["desc"]), 12, Color("#544330"))
		desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		desc.custom_minimum_size = Vector2(0, 58)
		desc.size_flags_vertical = Control.SIZE_EXPAND_FILL
		cv.add_child(desc)
		var owned := equipped.has(id)
		var amount := int(charges.get(id, 0))
		cv.add_child(_label("보유 ×%d" % amount, 12, INK_SOFT))
		var buy := Button.new()
		buy.focus_mode = Control.FOCUS_NONE
		buy.custom_minimum_size = Vector2(0, 38)
		buy.add_theme_font_override("font", FONT_DISPLAY)
		buy.add_theme_font_size_override("font_size", 17)
		buy.add_theme_color_override("font_color", CREAM)
		buy.add_theme_color_override("font_disabled_color", Color(0.4, 0.35, 0.28, 0.6))
		buy.add_theme_stylebox_override("normal", _round_style(TEAL, GOLD, 9))
		buy.add_theme_stylebox_override("hover", _round_style(Color("#2a7a84"), GOLD, 9))
		buy.add_theme_stylebox_override("pressed", _round_style(TEAL_DARK, GOLD, 9))
		buy.add_theme_stylebox_override("disabled", _round_style(Color("#d6c7a8"), Color("#a3906e"), 9))
		buy.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		var price := int(item["price"])
		var reason := ""
		if amount >= 3:
			reason = "가득 참"
		elif not owned and equipped.size() >= 2:
			reason = "주머니 가득"
		elif int(info.get("scrap", 0)) < price:
			reason = "%d 폐품 필요" % price
		else:
			reason = "%d 폐품에 사기" % price
		buy.text = reason
		buy.disabled = amount >= 3 or (not owned and equipped.size() >= 2) or int(info.get("scrap", 0)) < price
		buy.pressed.connect(_on_buy_pressed.bind(id))
		cv.add_child(buy)

	var footer := HBoxContainer.new()
	footer.add_theme_constant_override("separation", 10)
	col.add_child(footer)
	footer.add_child(_label("주머니", 14, INK))
	for i in 2:
		var slot := PanelContainer.new()
		slot.custom_minimum_size = Vector2(150, 38)
		slot.add_theme_stylebox_override("panel", _paper_style(Color("#e7d8b8"), Color("#9d8766"), 2, 10, 0))
		footer.add_child(slot)
		var text := "빈 주머니"
		if i < equipped.size():
			var eid := str(equipped[i])
			text = "%s ×%d" % [MoleData.ITEMS[eid]["short"], int(charges.get(eid, 0))]
		var sl := _label(text, 13, INK if i < equipped.size() else Color(0.42, 0.37, 0.3, 0.55))
		sl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		sl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		slot.add_child(sl)

	var msg := str(info.get("message", ""))
	if msg != "":
		var ml := _label(msg, 13, RED)
		ml.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		footer.add_child(ml)

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer.add_child(spacer)

	var depart := Button.new()
	depart.focus_mode = Control.FOCUS_NONE
	depart.text = "기어 나가기"
	depart.custom_minimum_size = Vector2(210, 50)
	depart.add_theme_font_override("font", FONT_DISPLAY)
	depart.add_theme_font_size_override("font_size", 22)
	depart.add_theme_color_override("font_color", CREAM)
	depart.add_theme_stylebox_override("normal", _round_style(TEAL, GOLD, 11))
	depart.add_theme_stylebox_override("hover", _round_style(Color("#2a7a84"), GOLD, 11))
	depart.add_theme_stylebox_override("pressed", _round_style(TEAL_DARK, GOLD, 11))
	depart.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	depart.pressed.connect(func(): depart_requested.emit())
	footer.add_child(depart)

	var fine := _label("주머니에는 두 가지까지. 한 번 쓰면 끝.   ·   헬멧은 자동으로 버텨 줍니다.", 11, Color(0.35, 0.3, 0.24, 0.55))
	col.add_child(fine)

func _on_buy_pressed(id: String) -> void:
	buy_requested.emit(id)

# ---------------------------------------------------------------- death / ending

func show_dead(scrap: int, time: float) -> void:
	_clear_overlay()
	hud_root.visible = false
	touch.set_enabled(false)
	overlay_root.visible = true
	_add_dim()

	var center := _center()
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(560, 430)
	panel.add_theme_stylebox_override("panel", _paper_style(PAPER, INK, 3, 20, 8))
	center.add_child(panel)
	var margin := _margin(34, 28, 30, 26)
	panel.add_child(margin)
	var col := VBoxContainer.new()
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 8)
	margin.add_child(col)

	col.add_child(_center_label("여기까지", 14, GOLD))
	col.add_child(_center_label("밟혔다", 52, RED, FONT_DISPLAY))
	col.add_child(_center_label("운동화 밑창 아래. 흙더미를 덜 남기면 덜 밟힌다.", 15, INK))
	var stat := _center_label("모은 폐품  %d" % scrap, 19, INK, FONT_DISPLAY)
	col.add_child(stat)
	col.add_child(_center_label("이번 구간  %s" % MoleData.fmt_time(time), 14, INK_SOFT))
	var retry := _big_button("다시 도전", TEAL)
	retry.pressed.connect(func(): retry_requested.emit())
	col.add_child(retry)

func show_win(total: float, scrap: int, best: float, is_best: bool, stage_times: Array, stage_names: Array) -> void:
	_clear_overlay()
	hud_root.visible = false
	touch.set_enabled(false)
	overlay_root.visible = true
	_add_dim()

	var center := _center()
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(720, 596)
	panel.add_theme_stylebox_override("panel", _paper_style(PAPER, INK, 3, 22, 8))
	center.add_child(panel)
	var margin := _margin(38, 24, 34, 22)
	panel.add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	margin.add_child(col)

	col.add_child(_center_label("해냈다", 14, GOLD))
	col.add_child(_center_label("깊은 수풀", 46, GREEN, FONT_DISPLAY))
	col.add_child(_center_label("배수로 끝. 인간 소리가 멀어지고, 젖은 흙 냄새만 남았다.", 14, INK))
	col.add_child(_center_label("최종 폐품  %d" % scrap, 16, INK))

	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 1)
	list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(list)
	for i in stage_names.size():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		list.add_child(row)
		var idx := _label("%d" % (i + 1), 12, GOLD)
		idx.custom_minimum_size = Vector2(20, 0)
		row.add_child(idx)
		var name_l := _label(str(stage_names[i]), 13, INK)
		name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(name_l)
		var t := float(stage_times[i]) if i < stage_times.size() else 0.0
		row.add_child(_label(MoleData.fmt_time(t) if t > 0.0 else "—", 13, INK_SOFT))

	col.add_child(_center_label("총 시간  %s%s" % [MoleData.fmt_time(total), "   ·   최고 기록!" if is_best else ""], 20, INK, FONT_DISPLAY))
	if best >= 0.0 and not is_best:
		col.add_child(_center_label("최고 기록  %s" % MoleData.fmt_time(best), 13, INK_SOFT))
	var again := _big_button("처음부터", TEAL)
	again.pressed.connect(func(): restart_requested.emit())
	col.add_child(again)

# ---------------------------------------------------------------- overlay helpers

func _clear_overlay() -> void:
	for c in overlay_root.get_children():
		overlay_root.remove_child(c)
		c.queue_free()

func _add_dim() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0.03, 0.05, 0.04, 0.74)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay_root.add_child(dim)

func _center() -> CenterContainer:
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay_root.add_child(center)
	return center

func _margin(l: int, t: int, r: int, b: int) -> MarginContainer:
	var m := MarginContainer.new()
	m.add_theme_constant_override("margin_left", l)
	m.add_theme_constant_override("margin_right", r)
	m.add_theme_constant_override("margin_top", t)
	m.add_theme_constant_override("margin_bottom", b)
	return m

func _center_label(text: String, size: int, color: Color, font: Font = null) -> Label:
	var l := _label(text, size, color, font)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

func _big_button(text: String, color: Color) -> Button:
	var b := Button.new()
	b.focus_mode = Control.FOCUS_NONE
	b.text = text
	b.custom_minimum_size = Vector2(0, 54)
	b.add_theme_font_override("font", FONT_DISPLAY)
	b.add_theme_font_size_override("font_size", 23)
	b.add_theme_color_override("font_color", CREAM)
	b.add_theme_stylebox_override("normal", _round_style(color, GOLD, 11))
	b.add_theme_stylebox_override("hover", _round_style(color.lightened(0.12), GOLD, 11))
	b.add_theme_stylebox_override("pressed", _round_style(color.darkened(0.15), GOLD, 11))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	return b

# ---------------------------------------------------------------- style helpers

func _label(text: String, size: int, color: Color, font: Font = null) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", font if font != null else FONT_BODY)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _pill(bg := Color(0.965, 0.92, 0.84, 0.92)) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = Color(0.24, 0.18, 0.12, 0.85)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(18)
	sb.content_margin_left = 11
	sb.content_margin_right = 12
	sb.content_margin_top = 5
	sb.content_margin_bottom = 5
	sb.shadow_color = Color(0.1, 0.08, 0.05, 0.28)
	sb.shadow_size = 4
	sb.shadow_offset = Vector2(0, 2)
	p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return p

func _chip() -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.12, 0.09, 0.72)
	sb.border_color = Color(0.91, 0.8, 0.58, 0.5)
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(14)
	sb.content_margin_left = 16
	sb.content_margin_right = 16
	sb.content_margin_top = 6
	sb.content_margin_bottom = 6
	p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return p

func _paper_style(bg: Color, border: Color, width: int, radius: int, shadow: int) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(width)
	sb.set_corner_radius_all(radius)
	sb.shadow_color = Color(0.12, 0.09, 0.05, 0.35)
	sb.shadow_size = shadow
	sb.shadow_offset = Vector2(0, 4)
	sb.anti_aliasing = true
	return sb

func _round_style(bg: Color, border: Color, radius: int) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(radius)
	sb.shadow_color = Color(0.1, 0.08, 0.05, 0.3)
	sb.shadow_size = 4
	sb.shadow_offset = Vector2(0, 3)
	sb.anti_aliasing = true
	return sb

func _bar_bg() -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.25, 0.2, 0.14, 0.22)
	sb.set_corner_radius_all(6)
	return sb

func _bar_fill(color: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(6)
	return sb

# ---------------------------------------------------------------- drawn icons

class CoinIcon:
	extends Control
	func _init() -> void:
		custom_minimum_size = Vector2(18, 18)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void:
		var c := size * 0.5
		var r: float = minf(size.x, size.y) * 0.46
		draw_circle(c, r, Color("#b98c46"))
		draw_circle(c, r * 0.78, Color("#e8cd8c"))
		draw_circle(c, r * 0.5, Color("#c9a95a"))
		draw_arc(c, r, 0, TAU, 24, Color("#6b4c1f"), 1.5, true)

## One of the three health hearts. The solid heart lives inside a clipped
## Control that is only as wide as the remaining health, so a heart can be
## full, half or just a sliver without any textures.
class HeartMeter:
	extends Control
	const W := 25.0
	const H := 23.0
	var clip: Control
	var filled: HeartShape

	func _init() -> void:
		custom_minimum_size = Vector2(W, H)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		clip = Control.new()
		clip.mouse_filter = Control.MOUSE_FILTER_IGNORE
		clip.clip_contents = true
		clip.size = Vector2(W, H)
		add_child(clip)
		filled = HeartShape.new()
		filled.size = Vector2(W, H)
		clip.add_child(filled)

	func set_fill(value: float) -> void:
		var amount := clampf(value, 0.0, 1.0)
		clip.visible = amount > 0.01
		clip.size = Vector2(W * amount, H)

	func _draw() -> void:
		var c := Vector2(W, H) * 0.5
		var s: float = minf(W, H) / 23.0
		var empty := Color(0.28, 0.21, 0.15, 0.22)
		draw_circle(c + Vector2(-4.6, -3.1) * s, 6.0 * s, empty)
		draw_circle(c + Vector2(4.6, -3.1) * s, 6.0 * s, empty)
		var pts := PackedVector2Array([
			c + Vector2(-10.6, -1.2) * s, c + Vector2(10.6, -1.2) * s,
			c + Vector2(0, 10.8) * s,
		])
		draw_colored_polygon(pts, empty)

class HeartShape:
	extends Control
	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void:
		var c := size * 0.5
		var s: float = minf(size.x, size.y) / 23.0
		var tint := Color("#b54234")
		draw_circle(c + Vector2(-4.6, -3.1) * s, 6.0 * s, tint)
		draw_circle(c + Vector2(4.6, -3.1) * s, 6.0 * s, tint)
		var pts := PackedVector2Array([
			c + Vector2(-10.6, -1.2) * s, c + Vector2(10.6, -1.2) * s,
			c + Vector2(0, 10.8) * s,
		])
		draw_colored_polygon(pts, tint)
		draw_circle(c + Vector2(-3.2, -4.4) * s, 2.0 * s, Color(1, 0.84, 0.78, 0.7))

class BreathIcon:
	extends Control
	func _init() -> void:
		custom_minimum_size = Vector2(18, 18)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void:
		for i in 3:
			var y := 4.0 + i * 5.0
			draw_arc(Vector2(5, y), 3.2, -PI * 0.8, PI * 0.8, 10, Color("#4d8fa8"), 1.7, true)
			draw_arc(Vector2(12, y), 3.2, PI * 0.2, PI * 1.8, 10, Color("#4d8fa8"), 1.7, true)

class ClockIcon:
	extends Control
	func _init() -> void:
		custom_minimum_size = Vector2(18, 18)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void:
		var c := size * 0.5
		draw_circle(c, 8.0, Color(0.25, 0.19, 0.13, 0.1))
		draw_arc(c, 7.4, 0, TAU, 28, Color("#4a3826"), 1.8, true)
		draw_line(c, c + Vector2(0, -4.6), Color("#4a3826"), 1.8, true)
		draw_line(c, c + Vector2(3.4, 1.6), Color("#4a3826"), 1.8, true)

class DistanceIcon:
	extends Control
	func _init() -> void:
		custom_minimum_size = Vector2(18, 18)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void:
		var c := size * 0.5
		draw_arc(c + Vector2(0, 2), 6.4, PI * 1.1, PI * 1.9, 12, Color("#4a3826"), 1.8, true)
		var pts := PackedVector2Array([c + Vector2(4, -7), c + Vector2(8.5, -1.5), c + Vector2(1.5, -1.5)])
		draw_colored_polygon(pts, Color("#4a3826"))

class PawIcon:
	extends Control
	func _init() -> void:
		custom_minimum_size = Vector2(40, 40)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void:
		var c := size * 0.5
		var ink := Color("#3a2c20")
		draw_circle(c + Vector2(0, 5), 10.0, ink)
		for p in [Vector2(-13, -6), Vector2(-4.5, -12), Vector2(4.5, -12), Vector2(13, -6)]:
			draw_circle(c + p, 5.2, ink)

class BottleIcon:
	extends Control
	func _init() -> void:
		custom_minimum_size = Vector2(26, 26)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void:
		var c := size * 0.5
		var col := Color("#f0dfb8")
		var r := Rect2(c + Vector2(-5, -3), Vector2(10, 13))
		draw_rect(r, col)
		draw_rect(Rect2(c + Vector2(-2.5, -10), Vector2(5, 8)), col)
		draw_rect(Rect2(c + Vector2(-3.5, -12), Vector2(7, 3)), Color("#c9a95a"))
		draw_rect(Rect2(c + Vector2(-3, 1), Vector2(6, 3)), Color("#718a56"))

class NavArrow:
	extends Control
	func _init() -> void:
		custom_minimum_size = Vector2(22, 22)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		pivot_offset = Vector2(11, 11)
	func _draw() -> void:
		var c := size * 0.5
		var pts := PackedVector2Array([c + Vector2(0, -8), c + Vector2(6.5, 6), c + Vector2(0, 2.8), c + Vector2(-6.5, 6)])
		draw_colored_polygon(pts, Color("#f0d18a"))
