# 두더지의 탈출 — UNDER THE BOOTS (Godot 4)

웹으로 만든 3인칭 두더지 잠입 게임을 **Godot 4.3** 프로젝트로 옮긴 버전입니다.
7개 구간, 잠수(땅파기)·산소·체력, 사람 AI와 밟기 공격, 가죽점(상점), 타임어택 기록,
가로 모드 터치 조작까지 들어 있습니다.

- 엔진: Godot **4.3** 이상 (GL Compatibility 렌더러, iOS/Android/데스크톱)
- 외부 유료 에셋 없음 · 모든 3D 모델은 코드로 생성
- 타이틀 일러스트와 마스코트는 웹 버전의 SVG를 그대로 사용
- 사운드는 런타임에 합성하는 절차적 SFX
- 네트워크 · 광고 · 분석 · 인앱결제 없음

## 바로 실행

1. Godot 4.3 이상을 설치합니다.
2. `project.godot`을 엽니다 (이 `godot/` 폴더를 프로젝트로 선택).
3. F5.

| 조작 | 데스크톱 | 아이폰/아이패드 |
| --- | --- | --- |
| 이동 | WASD / 방향키 | 좌측 스틱 |
| 시점 | 마우스 드래그 | 우측 드래그 |
| 잠수 | Space (누르고 있기) | 파기 버튼 (누르고 있기) |
| 아이템 | F 또는 E | 아이템 버튼 |
| 질주 | Shift 또는 스틱 끝까지 | 스틱 끝까지 |

> 잠수는 흙·모래·잔디에서만 가능합니다. 콘크리트/아스팔트에서는 "불가"로 표시됩니다.
> 마지막 구간의 철망은 지상에서는 막히고, 땅속으로만 통과할 수 있습니다.

## 폴더 구조

```
godot/
  project.godot          # 1280x720, 가로 모드, GL Compatibility
  export_presets.cfg     # iOS 프리셋 (아이콘/가로/개인정보 설정 포함)
  scenes/main.tscn       # Node3D + game.gd
  scripts/
    data.gd              # 7개 구간 데이터 (웹 src/data.js와 동일)
    game.gd              # 게임 흐름, 상점, 기록, 엔딩
    world.gd             # 절차적 파크/거리/공사장/주차장/정원/배수로
    player.gd            # 잠수 상태머신, 산소, 체력, 카메라
    mole_model.gd        # 로우폴리 두더지
    human.gd             # 보행자 AI (순찰/추격/흙더미 조사/밟기)
    humans.gd            # 구간별 사람 스폰 (마지막 20명)
    hud.gd               # 하트 3개 체력, 산소, 타이머, 상점/사망/엔딩 UI
    touch_controls.gd    # 멀티터치 스틱 + 시점 + 파기/아이템
    title_screen.gd      # 나무 액자 타이틀 화면
    sfx.gd               # 절차적 효과음
  assets/
    title.svg            # 타이틀 일러스트 (Godot SVG 임포터로 렌더)
    mascot.svg
    fonts/               # Jua, Gowun Dodum (OFL 라이선스 포함)
    ios/AppIcon-*.png     # iOS 앱 아이콘 (1024 포함, 알파 없음)
  tests/smoke.gd         # 헤드리스 로직 테스트
  icon.svg
```

## iOS / App Store 빌드

> **중요:** iOS 빌드는 macOS + Xcode에서만 가능합니다. 이 Linux 작업 공간에서는
> Xcode/iOS 익스포트 템플릿이 없어 `.ipa`/아카이브를 만들 수 없습니다.
> 아래는 맥에서 그대로 따라 하는 순서입니다.

### 준비물

- macOS 13 이상, Xcode 15 이상
- Apple Developer Program 멤버십
- Godot 4.3+ (macOS판)과 **iOS Export Templates**
  - Godot 메뉴 → `Editor > Manage Export Templates…` → Download
- App Store Connect에 등록할 앱 이름과 **번들 ID** (예: `com.yourstudio.moleescape`)

### 1) 프로젝트 열기

1. Godot에서 `godot/project.godot`을 엽니다.
2. F5로 데스크톱에서 한 번 플레이해 조작을 확인합니다.
3. `Project > Export…` → 왼쪽에 **iOS** 프리셋이 이미 있습니다.
   - `App Store Team ID`: 본인 팀 ID (10자리)
   - `Bundle Identifier`: App Store Connect에서 쓸 ID로 변경
   - `Version` / `Build`: 첫 업로드는 `1.0` / `1`, 이후 TestFlight 업로드마다 Build 증가
   - `Export Project Only`가 켜져 있어 Xcode 프로젝트까지만 생성합니다.
4. `Export Project` → `godot/build/ios/`에 Xcode 프로젝트가 생성됩니다.

### 2) Xcode에서 서명 및 실행

1. 생성된 `.xcodeproj`를 Xcode로 엽니다.
2. 대상(Target) → `Signing & Capabilities`
   - Team 선택, `Automatically manage signing` 켜기
   - Bundle Identifier 확인
3. 아이폰/아이패드를 연결하거나 시뮬레이터를 선택하고 Run.
   - 가로 모드로 실행되는지, 스틱+파기 동시 터치가 되는지 꼭 확인하세요.
4. 실기기에서 `Product > Archive` → Organizer → `Distribute App` →
   `App Store Connect` → Upload.

### 3) App Store Connect

- 앱 생성: 게임 / 액션 또는 아케이드, 가로 모드
- iPad는 전체 화면 게임으로 설정되어 있습니다(`UIRequiresFullScreen`).
- 스크린샷: 6.9인치 iPhone(필수), iPad 지원 시 13인치 iPad 스크린샷
- 개인정보: **Data Not Collected** (서버·광고·분석 없음)
  - 기록은 기기 내부 `user://records.cfg`에만 저장됩니다.
  - 개인정보 처리방침 URL과 지원 URL은 App Store Connect가 요구합니다.
- 연령 등급: 만화풍 밟기 표현이 있어 9+ 정도를 권장합니다.
- 심사 메모: "Single-player offline arcade game. No account, no network, no purchases."

### 앱 아이콘

`assets/ios/AppIcon-1024.png`는 알파 채널이 없는 불투명 PNG이며, 나머지 iOS 규격
아이콘도 같은 폴더에 들어 있습니다. 아이콘을 바꾸려면 `icon.svg`를 수정한 뒤:

```bash
godot --headless --path . --script res://tests/make_icons.gd
```

## 검증 범위

이 작업 공간에서 실제로 확인한 것:

- Godot 4.3 헤드리스 임포트: 모든 스크립트/씬/SVG/폰트 로드 성공
- `tests/smoke.gd` 35개 체크 통과
  - 타이틀→게임 시작, 7구간 생성, 마지막 구간 사람 20명
  - 잠수 시작/전환/복귀, 산소 감소, 공중 5초 상한, 마지막 구간 4.6초
  - 밟기 30 피해, 헬멧 1회 방어
  - 철망 지상 차단 / 지하 통과
  - 상점 구매·폐품 차감, 스테이지 클리어→다음 상점, 사망→재도전 타이머 유지
- 타이틀 SVG를 Godot 임포터로 PNG 래스터화해 아트 확인 (`tests/render_assets.gd`)
- iOS 익스포트 프리셋 인식 확인 (익스포트 자체는 iOS 템플릿이 없어 중단됨)

확인하지 못한 것:

- iOS 기기/시뮬레이터에서의 실제 컴파일·아카이브 (macOS/Xcode 필요)
- Godot 런타임의 3D 화면·HUD 최종 렌더 (이 VM에는 GPU/디스플레이가 없음)
- 아이폰 실기기 프레임레이트 및 발열

## 라이선스

- 게임 코드/아트: 원 프로젝트와 동일
- 폰트: `assets/fonts/OFL-*.txt` 참고 (SIL Open Font License 1.1)
