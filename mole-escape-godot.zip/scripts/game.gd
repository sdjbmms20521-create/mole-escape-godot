extends Node3D

## Game flow: title, 7 stages, shop, records, death and ending.

enum Mode { MENU, PLAYING, SHOP, DEAD, WON, ESCAPED }

const RECORD_PATH := "user://records.cfg"
const STAGE_COUNT := 7

var mode: int = Mode.MENU
var title: TitleScreen
var hud: GameHUD
var sfx: Sfx
var world: MoleWorld
var player: MolePlayer
var humans: Humans
var camera: Camera3D
var sun: DirectionalLight3D
var world_env: WorldEnvironment
var env: Environment
var sky_mat: ProceduralSkyMaterial

var stage_index := 0
var shop_index := 0
var retrying := false
var scrap := 0
var charges := {"helmet": 0, "drink": 0, "nav": 0}
var equipped: Array = []
var elapsed := 0.0
var stage_time := 0.0
var run_time := 0.0
var run_times: Array = []
var last_result: Dictionary = {}
var nav_until := 0.0
var heartbeat_timer := 0.0
var shop_message := ""
var labels_shown := false
var records := {"stages": {}, "total": -1.0}

func _ready() -> void:
	randomize()
	if OS.has_feature("mobile"):
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_SENSOR_LANDSCAPE)
	_setup_environment()
	_setup_camera()

	sfx = Sfx.new()
	sfx.name = "Sfx"
	add_child(sfx)

	hud = GameHUD.new()
	hud.name = "HUD"
	add_child(hud)
	hud.setup()
	hud.item_pressed.connect(_use_item)
	hud.buy_requested.connect(_on_buy)
	hud.depart_requested.connect(_on_depart)
	hud.retry_requested.connect(_on_retry)
	hud.restart_requested.connect(_on_restart)

	title = TitleScreen.new()
	title.name = "Title"
	add_child(title)
	title.start_pressed.connect(_on_start)

	_load_records()
	mode = Mode.MENU

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		if hud != null and mode == Mode.PLAYING:
			hud.touch.set_enabled(false)
	elif what == NOTIFICATION_APPLICATION_FOCUS_IN or what == NOTIFICATION_WM_WINDOW_FOCUS_IN:
		if hud != null and mode == Mode.PLAYING:
			hud.touch.set_enabled(true)

func _setup_environment() -> void:
	world_env = WorldEnvironment.new()
	env = Environment.new()
	var sky := Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("#7fb0d6")
	sky_mat.sky_horizon_color = Color("#e3e8dd")
	sky_mat.ground_horizon_color = Color("#cbd9cf")
	sky_mat.ground_bottom_color = Color("#59684f")
	sky_mat.sun_angle_max = 16.0
	sky_mat.sun_curve = 0.12
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.6
	env.ambient_light_sky_contribution = 0.85
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.05
	env.fog_enabled = true
	env.fog_light_color = Color("#cbd9cf")
	env.fog_density = 0.007
	env.fog_sky_affect = 0.35
	env.fog_aerial_perspective = 0.25
	world_env.environment = env
	add_child(world_env)

	sun = DirectionalLight3D.new()
	sun.name = "Sun"
	sun.shadow_enabled = true
	sun.light_color = Color("#ffe6bd")
	sun.light_energy = 1.35
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_max_distance = 55.0
	sun.directional_shadow_blend_splits = true
	sun.shadow_bias = 0.04
	sun.shadow_normal_bias = 1.0
	sun.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_AND_SKY
	add_child(sun)

func _setup_camera() -> void:
	camera = Camera3D.new()
	camera.name = "GameCamera"
	camera.fov = 66.0
	camera.near = 0.02
	camera.far = 420.0
	camera.current = true
	add_child(camera)

# ---------------------------------------------------------------- game flow

func _on_start() -> void:
	if sfx != null:
		sfx.play("ui")
	title.hide_menu()
	start_run()

func start_run() -> void:
	scrap = 0
	charges = {"helmet": 0, "drink": 0, "nav": 0}
	equipped = []
	stage_index = 0
	run_time = 0.0
	run_times = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
	last_result = {}
	nav_until = 0.0
	build_stage(0, true)
	hud.show_game()
	_sync_item_ui()
	mode = Mode.PLAYING

func build_stage(index: int, reset_timer := true) -> void:
	stage_index = index
	var stage: Dictionary = MoleData.STAGES[index]

	if player != null:
		remove_child(player)
		player.queue_free()
		player = null
	if humans != null:
		remove_child(humans)
		humans.queue_free()
		humans = null
	if world != null:
		remove_child(world)
		world.queue_free()
		world = null

	world = MoleWorld.new()
	world.name = "World"
	add_child(world)
	world.setup(stage)

	player = MolePlayer.new()
	player.name = "Player"
	add_child(player)
	player.setup(world, camera, sfx)
	player.set_helmet(_has_helmet())
	player.set_air(float(stage.get("air", 7.6)))
	player.set_dig_cooldown(float(stage.get("dig_cooldown", 0.0)))

	humans = Humans.new()
	humans.name = "Humans"
	add_child(humans)
	humans.setup(world, stage)
	humans.stomped.connect(_on_stomp)

	elapsed = 0.0
	if reset_timer:
		stage_time = 0.0
	heartbeat_timer = 0.0
	nav_until = 0.0

	hud.set_scrap(scrap)
	hud.set_time(stage_time)
	hud.set_health(player.health)
	hud.set_oxygen(1.0, false)
	hud.set_distance(player.goal_distance())
	hud.set_danger(0.0)
	hud.set_buff_visual(false)
	hud.set_nav(null)
	_sync_item_ui()
	hud.set_dig(world.can_burrow(player.position.x, player.position.z), false, 0.0)
	hud.set_objective(str(stage.get("quest", "")), 6200)
	var hint_text := "좌측 드래그로 이동 · 우측 드래그로 시점 · 잠수는 흙 위에서만" if index == 0 else "딱딱한 바닥에서는 잠수할 수 없습니다"
	hud.hint(hint_text, 5200)
	_apply_stage_environment(stage)
	_follow_sun(stage)

func _apply_stage_environment(stage: Dictionary) -> void:
	var sky: Dictionary = stage.get("sky", {})
	sky_mat.sky_top_color = Color(str(sky.get("top", "#7fb0d6")))
	sky_mat.sky_horizon_color = Color(str(sky.get("bottom", "#e3e8dd")))
	sky_mat.ground_horizon_color = Color(str(sky.get("fog", "#cbd9cf")))
	sky_mat.ground_bottom_color = Color(str(sky.get("fog", "#cbd9cf"))).darkened(0.55)
	env.fog_light_color = Color(str(sky.get("fog", "#cbd9cf")))
	var night := bool(stage.get("night", false))
	env.fog_density = 0.02 if night else 0.007
	env.ambient_light_energy = 0.34 if night else 0.62
	env.tonemap_exposure = 0.98 if night else 1.05
	var sun_info: Dictionary = stage.get("sun", {})
	sun.light_color = Color(str(sun_info.get("color", "#ffe6bd")))
	sun.light_energy = float(sun_info.get("intensity", 2.4)) * 0.6
	sun.visible = true

func _follow_sun(stage: Dictionary) -> void:
	if player == null or sun == null:
		return
	var p: Array = stage.get("sun", {}).get("pos", [24.0, 30.0, 16.0])
	sun.position = player.position + Vector3(float(p[0]), float(p[1]), float(p[2]))
	sun.look_at(player.position, Vector3.UP)

func _process(delta: float) -> void:
	if mode == Mode.PLAYING:
		_tick_playing(minf(delta, 0.05))

func _tick_playing(dt: float) -> void:
	if player == null or world == null or humans == null:
		return
	elapsed += dt
	stage_time += dt

	var axes := _gather_axes()
	var look := hud.touch.consume_look()
	var dig_held := hud.touch.dig_held or Input.is_physical_key_pressed(KEY_SPACE)
	var sprint := axes.length() > 0.86 or Input.is_physical_key_pressed(KEY_SHIFT)
	player.update(dt, axes, look, dig_held, sprint)
	world.tick(dt)
	humans.update(dt, player)

	for s in world.scrap:
		if bool(s["collected"]):
			continue
		if Vector2(float(s["x"]) - player.position.x, float(s["z"]) - player.position.z).length() < 0.62:
			var value := world.collect_scrap(s)
			if value > 0:
				scrap += value
				hud.set_scrap(scrap)
				sfx.play("pickup")

	var stage: Dictionary = MoleData.STAGES[stage_index]
	hud.set_time(stage_time)
	hud.set_distance(player.goal_distance())
	hud.set_oxygen(player.oxygen, player.underground())
	hud.set_health(player.health)
	hud.set_underground(player.underground())
	var burrowable := world.can_burrow(player.position.x, player.position.z)
	hud.set_dig(burrowable, player.underground(), player.dig_cooldown)
	hud.set_buff_visual(player.buff > 0.0)

	if nav_until > elapsed:
		var dx := world.goal.x - player.position.x
		var dz := world.goal.z - player.position.z
		var dist := maxf(0.1, sqrt(dx * dx + dz * dz))
		var nx := dx / dist
		var nz := dz / dist
		var right := nx * cos(player.yaw) + nz * -sin(player.yaw)
		var fwd := nx * -sin(player.yaw) + nz * -cos(player.yaw)
		hud.set_nav(rad_to_deg(atan2(right, fwd)), dist)
	elif nav_until > 0.0:
		nav_until = 0.0
		hud.set_nav(null)

	var nearest := humans.nearest_distance(player.position)
	var threat := maxf(0.0, 1.0 - nearest / 8.0)
	if player.oxygen < 0.5:
		threat = maxf(threat, (0.5 - player.oxygen) / 0.5)
	hud.set_danger(threat)
	heartbeat_timer -= dt
	if threat > 0.22 and heartbeat_timer <= 0.0:
		heartbeat_timer = 0.52 if player.oxygen < 0.32 else 0.72 if threat > 0.55 else 1.0
		sfx.play("heart", -26.0 + threat * 10.0, 0.9 + threat * 0.2)

	_follow_sun(stage)

	if player.dead:
		_die()
		return
	if player.goal_distance() < 1.35 and player.state == MolePlayer.SURFACE:
		_escape()

func _gather_axes() -> Vector2:
	var v := hud.touch.move
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
		v.y += 1.0
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
		v.y -= 1.0
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
		v.x -= 1.0
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
		v.x += 1.0
	if v.length() > 1.0:
		v = v.normalized()
	return v

func _input(event: InputEvent) -> void:
	if mode == Mode.PLAYING and event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F or event.keycode == KEY_E:
			_use_item()

# ---------------------------------------------------------------- items

func _has_helmet() -> bool:
	return equipped.has("helmet") and int(charges.get("helmet", 0)) > 0

func _sync_item_ui() -> void:
	var text := "없음"
	var count := 0
	var usable := false
	for id in equipped:
		var item: Dictionary = MoleData.ITEMS[id]
		if not bool(item["passive"]) and int(charges.get(id, 0)) > 0:
			text = str(item["short"])
			count = int(charges.get(id, 0))
			usable = true
			break
	hud.set_item(text, count, not usable)

func _use_item() -> void:
	if mode != Mode.PLAYING or player == null:
		return
	var id := ""
	for item_id in equipped:
		var item: Dictionary = MoleData.ITEMS[item_id]
		if not bool(item["passive"]) and int(charges.get(item_id, 0)) > 0:
			id = str(item_id)
			break
	if id == "":
		hud.hint("아이템 없음 — 잡화점에서 사세요", 2200)
		return
	if player.state != MolePlayer.SURFACE:
		hud.hint("땅 위에서만 사용할 수 있습니다", 1600)
		return

	if id == "drink":
		player.apply_buff(12.0)
		hud.set_buff_visual(true)
		hud.hint("이온 드링크 — 12초간 질주", 2300)
		sfx.play("pickup", -8.0, 1.1)
	elif id == "nav":
		nav_until = elapsed + 15.0
		hud.hint("배수로 내비 — 15초간 방향 표시", 2300)
		sfx.play("ui")

	charges[id] = maxi(0, int(charges.get(id, 0)) - 1)
	if int(charges[id]) == 0:
		equipped.erase(id)
	_sync_item_ui()
	sfx.play("ui", -12.0)

# ---------------------------------------------------------------- hazards

func _on_stomp(info: Dictionary) -> void:
	if mode != Mode.PLAYING or player == null:
		return
	var target: Vector3 = info.get("pos", Vector3.ZERO)
	var d := Vector2(player.position.x - target.x, player.position.z - target.z).length()
	if d < 8.0:
		player.add_shake(0.35 + (1.0 - d / 8.0) * 0.6)
		hud.set_danger(minf(1.0, (1.0 - d / 8.0) * 1.1))
	sfx.play("stomp", -16.0, randf_range(0.92, 1.06))

	var result := player.handle_stomp(info)
	if result == "hit" or result == "dead":
		hud.flash_damage()
		hud.set_danger(1.0)
		if result == "dead":
			_die()
	elif result == "helmet":
		hud.flash_damage()
		charges["helmet"] = 0
		equipped.erase("helmet")
		player.set_helmet(false)
		_sync_item_ui()
		hud.hint("도토리 껍질이 부서졌습니다 — 튕겨 나왔습니다", 2800)
		sfx.play("crack")

func _die() -> void:
	if mode != Mode.PLAYING:
		return
	mode = Mode.DEAD
	hud.hide_game()
	hud.set_underground(false)
	if sfx != null:
		sfx.play("hurt", -3.0, 0.85)
	var t := stage_time
	await get_tree().create_timer(0.85).timeout
	if mode == Mode.DEAD:
		hud.show_dead(scrap, t)

func _escape() -> void:
	if mode != Mode.PLAYING:
		return
	mode = Mode.ESCAPED
	hud.hide_game()
	hud.set_underground(false)
	hud.set_oxygen(1.0, false)
	if sfx != null:
		sfx.play("win")

	var idx := stage_index
	var t := stage_time
	run_time += t
	while run_times.size() <= idx:
		run_times.append(0.0)
	run_times[idx] = t
	nav_until = 0.0
	hud.set_nav(null)

	var key := str(idx)
	var prev: float = float(records["stages"].get(key, -1.0))
	var is_best := prev < 0.0 or t < prev
	if is_best:
		records["stages"][key] = t
	last_result = {"index": idx, "time": t, "best": float(records["stages"].get(key, t)), "is_best": is_best}
	_save_records()

	var last := idx >= STAGE_COUNT - 1
	await get_tree().create_timer(0.9 if last else 0.75).timeout
	if mode != Mode.ESCAPED:
		return
	if last:
		mode = Mode.WON
		var prev_total: float = float(records.get("total", -1.0))
		var is_best_total := prev_total < 0.0 or run_time < prev_total
		if is_best_total:
			records["total"] = run_time
			_save_records()
		var names: Array = []
		for st in MoleData.STAGES:
			names.append(str(st["name"]))
		hud.show_win(run_time, scrap, float(records.get("total", run_time)), is_best_total, run_times, names)
	else:
		_open_shop(idx + 1, false)

# ---------------------------------------------------------------- shop

func _open_shop(index: int, is_retry: bool) -> void:
	mode = Mode.SHOP
	shop_index = index
	retrying = is_retry
	shop_message = ""
	hud.hide_game()
	hud.show_shop(_shop_info())

func _shop_info() -> Dictionary:
	var stage: Dictionary = MoleData.STAGES[shop_index]
	return {
		"name": stage["name"],
		"sub": stage["sub"],
		"brief": stage["brief"],
		"index": shop_index,
		"total": STAGE_COUNT,
		"scrap": scrap,
		"charges": charges,
		"equipped": equipped,
		"best": float(records["stages"].get(str(shop_index), -1.0)),
		"message": shop_message,
	}

func _on_buy(id: String) -> void:
	if mode != Mode.SHOP:
		return
	var item: Dictionary = MoleData.ITEMS[id]
	var price := int(item["price"])
	if int(charges.get(id, 0)) >= 3:
		shop_message = "이 아이템은 세 개까지 들고 갈 수 있습니다."
		hud.show_shop(_shop_info())
		return
	if not equipped.has(id) and equipped.size() >= 2:
		shop_message = "주머니에는 두 가지까지. 하나를 다 쓰고 오세요."
		hud.show_shop(_shop_info())
		return
	if scrap < price:
		shop_message = "폐품이 %d개 부족합니다." % (price - scrap)
		hud.show_shop(_shop_info())
		return
	if not equipped.has(id):
		equipped.append(id)
	charges[id] = int(charges.get(id, 0)) + 1
	scrap -= price
	shop_message = "%s을(를) 주머니에 넣었습니다." % str(item["name"])
	sfx.play("pickup", -6.0)
	hud.show_shop(_shop_info())

func _on_depart() -> void:
	if mode != Mode.SHOP:
		return
	var index := shop_index
	var keep_clock := retrying
	shop_message = ""
	build_stage(index, not keep_clock)
	hud.show_game()
	_sync_item_ui()
	mode = Mode.PLAYING
	sfx.play("ui")

func _on_retry() -> void:
	if mode != Mode.DEAD:
		return
	_open_shop(stage_index, true)

func _on_restart() -> void:
	start_run()

# ---------------------------------------------------------------- records

func _load_records() -> void:
	var cf := ConfigFile.new()
	var err := cf.load(RECORD_PATH)
	if err != OK:
		return
	var stages: Dictionary = {}
	for key in cf.get_section_keys("stages"):
		stages[key] = float(cf.get_value("stages", key, -1.0))
	records["stages"] = stages
	records["total"] = float(cf.get_value("total", "time", -1.0))

func _save_records() -> void:
	var cf := ConfigFile.new()
	for key in records["stages"]:
		cf.set_value("stages", str(key), float(records["stages"][key]))
	cf.set_value("total", "time", float(records.get("total", -1.0)))
	cf.save(RECORD_PATH)
